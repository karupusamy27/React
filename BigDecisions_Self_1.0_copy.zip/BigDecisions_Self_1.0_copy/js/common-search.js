
var searchCommon = [],
    searchInit = function () {
        $('.search-common').each(function (idx) {
            var $searchCommon = $(this);
            if ($searchCommon.data('searchIdx') == undefined) {
                idx = searchCommon.length;

                this.setAttribute('data-search-idx', idx);
                searchCommon[idx] = {
                    //$obj : $(document.querySelector('.search-common')),
                    $obj: $searchCommon,
                    canFocus: 0,
                    canSubmit: 0,
                    canCookie: 0,
                    minLength: 0,
                    cookieName: '',
                    action: '',
                    max: 10,
                    functionName: '',
                    $layer: null,
                    $input: null,
                    $recentArea: null,
                    $resultArea: null,
                    $template: null,
                    $btnSubmit: '',
                    $btnClose: '',
                    init: function () {
                        var el = this.$obj;
                        this.canFocus = el.data('canfocus');
                        this.canSubmit = el.data('cansubmit');
                        this.cookieName = el.data('cookiename');
                        this.functionName = el.data('function');
                        this.minLength = el.data('minlength') ? el.data('minlength') : 1;
                        this.$layer = el.find('.search-layer');
                        this.$input = el.find('.search-common-input');
                        this.$recentArea = this.$layer.find('.recent-suggested-type');
                        this.$resultArea = this.$layer.find('.search-result-list');
                        this.$template = this.$layer.find('template');
                        this.action = el.attr('action');
                        this.max = el.data('max');
                        this.$btnSubmit = el.find('input.submit');
                        this.$btnClose = el.find('.link-close');
                        if (this.cookieName) {
                            this.canCookie = 1;
                        }
                        // Recent, Focus and Input must be run when layer exists
                        if (this.$layer.length > 0) {
                            this.bindInput();

                            this.$input.on('keydown', function (e) {
                                if (e.keyCode === 9) {
                                    if (e.shiftKey) {
                                        $('.search-area .search-layer').removeClass('active');
                                    } else {
                                        var layer = $(this).closest('.search-common').find('.search-layer');
                                        if (layer.hasClass('active')) {
                                            e.preventDefault();
                                            var close = layer.find('.predictive-search:visible').find('.search-footer-area a.link-close');
                                            if (close && close.length > 0) {
                                                close[0].focus();
                                            }
                                        }

                                    }
                                }
                            });
                            // 20200406 END

                        }
                        this.$btnClose.on('click', function (e) {
                            e.preventDefault();
                            // 20200525 START 
                            if (searchCommon[idx].$btnSubmit.length > 0) searchCommon[idx].$input.focus();
                            // 20200406 END
                            var thisLayer = searchCommon[idx].$layer;
                            setTimeout(function () {
                                thisLayer.removeClass('active');
                            }, 100);
                            // 20200525 END
                        });

                        // Submit
                        this.bindSubmit();

                        // Close search layer
                        $('body').on('click touchend', function (event) {
                            if (!$(event.target).parents('.search-area')[0]) {
                                searchCommon[idx].$layer.removeClass('active');
                            }
                        });
                        // Close the search layer when blur event occurs at the end of the search layer
                        this.$recentArea.find('ul.list:last-child li:last-child a').on('blur', function () {
                            searchCommon[idx].$layer.removeClass('active');
                        });
                        this.$resultArea.find('.search-result-seemore a').on('blur', function () {
                            searchCommon[idx].$layer.removeClass('active');
                        });

                        // init
                        this.$input.data('oldtext', ''); // for ie11 bug
                    },
                    bindNoFocus: function () {
                        if ($('.search-model-result').length > 0) {
                            // manuals and documents, software and drivers page only
                            this.$input.on('focus', function (e) {
                                e.preventDefault();
                                if (!searchCommon[idx].$layer.hasClass('active')) {
                                    searchCommon[idx].$layer.addClass('active');
                                }
                            });
                        }
                    },
                    bindFocus: function () {
                        this.$input.on('focus', function (e) {
                            e.preventDefault();
                            // check the cookie
                            // open the layer
                            if (!searchCommon[idx].$layer.hasClass('active')) {
                                searchCommon[idx].$layer.addClass('active');
                            }
                            searchCommon[idx].doRecent();
                        });
                    },
                    bindInput: function () {
                        /* this.$input.on('input', function (e) {
                             e.preventDefault();
                             var keyword = document.getElementById("search-keyword").value
                             var result = document.getElementsByClassName("not-result");
 
                             axios.post(`http://23.96.126.193:9200/search/`, { query: keyword, mode: 'cors' })
                                  .then(function (response) {
                                     // console.log(response);
                                     result[0].innerHTML ='';
                                      if(!response.data)
                                      {
                                          result[0].innerHTML = "There are no related contents.";
                                      }else{
                                         response.data.map((value, key) => {
                                             if(key===response.data.length-1){
                                                 result[0].innerHTML+='<a href="#">'+value['id'] +' = ' + value['shortDesc'] + '</a>' ;
                                             }else{
                                                 result[0].innerHTML+='<a href="#">'+value['id'] +' = ' + value['shortDesc'] + '</a>'+'<br><br>';
                                             }
                                         })
                                      }
                                  })
                                  .catch(function (error) {
                                      if (error.response) {
                                          result[0].innerHTML = "There are no related contents.";
                                          console.log(error.response);
                                      }
                                    });
                             // check the cookie
 
                             // check the input's value
                             if (searchCommon[idx].$input.val() == '' && (searchCommon[idx].$input.data('oldtext') != searchCommon[idx].$input.val())) {
                                 searchCommon[idx].doRecent();
                                 // open the layer
                                 if (!searchCommon[idx].$layer.hasClass('active')) {
                                     searchCommon[idx].$layer.addClass('active');
                                     
                                     
                                 }
                             } else if (searchCommon[idx].minLength <= searchCommon[idx].$input.val().length) {
                                 searchCommon[idx].doResult();
                                 // open the layer
                                 if (!searchCommon[idx].$layer.hasClass('active')) {
                                     searchCommon[idx].$layer.addClass('active');
                                 }
                             }
                             searchCommon[idx].$input.data('oldtext', searchCommon[idx].$input.val());
                         });
                         // REQ-022 : 스크립트 추가 시작
                         this.$input.on('focus', function (e) {
                             if (searchCommon[idx].$input.closest('.GPC0009').length > 0) {
                                 searchCommon[idx].doResult();
                                 // open the layer
                                 if (!searchCommon[idx].$layer.hasClass('active')) {
                                     searchCommon[idx].$layer.addClass('active');
                                 }
                             }
                         });
                         // REQ-022 : 
                         */
                    },
                    bindSubmit: function () {

                        this.$btnSubmit.on('click', function (e) {
                            e.preventDefault();
                            var keyword = document.getElementById("search-keyword").value;
                            console.log(keyword);
                            location.href = `http://23.96.126.193:5047/search?q=${keyword}`;
                            /* var keyword = document.getElementById("search-keyword").value;
                             var result = document.getElementsByClassName("not-result");
                             
                             axios.post(`http://23.96.126.193:9200/search/`, { query:keyword,mode:'cors'})
                                 .then(function (response) {
                                     if(response.data== ' ')
                                     {
                                         result[0].innerHTML = "There are no related products.";
                                     }else{
                                         console.log(response.data);
                                         response.data.map((value,key)=>{
                                         
                                             console.log(value['id'] + ' = ' + value['shortDesc']+ key)
                                             result[key].innerHTML = `${value['id']} ${value['shortDesc']}`;
                                         })
                                         
                                     }
                                 })
                                 .catch(function (error) {
                                     if (error.response) {
                                         result[0].innerHTML = "There are no related products.";
                                     }
                                   });
                                   */

                        });
                    },
                    bindDeleteKeyword: function () {
                        searchCommon[idx].$recentArea.find('ul.list li a.delete').off('click', '**').on('click', function (e) {
                            e.preventDefault();
                            // Remove this in the list
                            $(this).closest('li').remove();
                            if (searchCommon[idx].$recentArea.find('ul.list.recent-keyword li').length <= 0) {
                                recentNoResult.show();
                                recentList.empty().hide();
                            }
                        });
                    },
                    doResult: function () {
                        this.$resultArea.show();
                        this.$recentArea.hide();
                        var noSubmitArea = this.$resultArea.find('.no-submit'),
                            url = this.$input.data('predictive-url'),
                            searchTxt = {};

                        noSubmitArea.hide();
                    },
                    doRecent: function () {
                        if (this.canFocus == 1) this.$recentArea.show();
                        this.$resultArea.hide();
                        // check the cookie
                    },
                };
                searchCommon[idx].init();
            }
        });
    };
(function ($) {
    if (!document.querySelector('.search-common')) return false;
    searchInit();
})(jQuery);
