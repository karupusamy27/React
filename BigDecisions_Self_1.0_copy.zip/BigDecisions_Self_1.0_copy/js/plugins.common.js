/*! lazysizes - v4.1.4
* https://github.com/aFarkas/lazysizes
*/

/*! Slick - 1.8.1
* https://kenwheeler.github.io/slick/
*/

/*!
 * InlineSVG
 *
 * This is a jQuery plugin that takes an image selector as an argument having a
 * SVG as source. Then it inlines the SVG so that the SVG stroke and path can
 * be manipulated using plain CSS.
 *
 * @license MIT
 * @version 2.0.0
 * @see {@link https://github.com/createlogic/InlineSVG|GitHub}
 *
 * The MIT License (MIT)
 *
 * Copyright (c) 2010-2015 Bilal Niaz Awan
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*!
 * jQuery Cookie Plugin v1.4.1
 * https://github.com/carhartl/jquery-cookie
 *
 * Copyright 2013 Klaus Hartl
 * Released under the MIT license
 */

 /*!
 * jQuery Mousewheel 3.1.13
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license
 * http://jquery.org/license
 */

// lazyload image (onerror)
	function srcErrorIMG($img, src) {
		if(!src || src=='') return false;
		$img.attr('src', src);
	}

	// product summary 
	var productSummaryImg1 = '/lg5-common-gp/images/common/product-default-desktop.jpg',
		productSummaryImg2 = '/lg5-common-gp/images/common/product-default-mobile.jpg';

	// list
	var productListImg1 = '/lg5-common-gp/images/common/product-default-list-350.jpg',
		productListImg2 = '/lg5-common-gp/images/common/product-default-list-260.jpg',
		productListImg3 = '/lg5-common-gp/images/common/product-default-list-165.jpg';

	function bindImgError() {

		// default
		$('img[data-error-img]').each(function() {
			$(this).off('error').on('error', function() {
				var defaultImg = $(this).attr('data-error-img');
				if(defaultImg) {
					$(this).off('error');
					console.log($(this).attr('class'), defaultImg);
					srcErrorIMG($(this), defaultImg);
				}
			});
		});
		// GPC0009
		$('.GPC0009 .pdp-visual-image img, .GPC0009 .pdp-visual .slick-slide img, #modal_detail_target .item img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				if($(this).closest('.hidden-sm').length>0) srcErrorIMG($(this), productSummaryImg1);
				else srcErrorIMG($(this), productSummaryImg2);
			});
		});
		$('.GPC0009 .pdp-thumbnail-nav .thumbnail img, .modal .modal-pdp-gallery .modal-body .thumbnail .image img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				srcErrorIMG($(this), productListImg3);
			});
		});
		$('.GPC0009 .pdp-thumbnail-nav .video img, .modal .modal-pdp-gallery .modal-body .thumbnail .video img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				srcErrorIMG($(this), '/lg5-common-gp/images/common/video-default-thumbnail.gif');
			});
		});

		// My LG > Index
		// 200421 START 
		$(window).on('load', function() {
			$('.mylg-index-wrap .item .visual img').each(function() {
				if (this.src != '' && (this.naturalWidth == 0 || typeof this.naturalWidth == "undefined")) {
					$(this).off('error');
					if($(this).hasClass('mobile')) srcErrorIMG($(this), productListImg2);
					else srcErrorIMG($(this), productListImg1);
				}
			});
		});
		// 200421 END 
		$('.mylg-index-wrap .my-repair-requests.table-list-wrap td img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				srcErrorIMG($(this), productListImg3);
			});
		});

		// My LG > Products 
		$('.my-product .product-info .product-info-img img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				srcErrorIMG($(this), productListImg3);
			});
		});
		$('.my-product .complete-list .image-cell img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				srcErrorIMG($(this), productListImg3);
			});
		});

		// CS > Right floating bar (only desktop)
		$('.right-floating-bar .viewed-item .imagbox img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				srcErrorIMG($(this), productListImg3);
			});
		});

		// CS > Home
		$('.support-wrap .solutions-contents .product-type .item .visual img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				if($(this).hasClass('mobile')) srcErrorIMG($(this), productListImg2);
				else srcErrorIMG($(this), productListImg1);
			});
		});

		// CS > PSP
		$('.support-wrap .support-product-area .visual img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				srcErrorIMG($(this), productListImg2);
			});
		});

		// CS > Step > My products
		$('.support-wrap .step-in-form .select-product .my-Products .item .visual img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				srcErrorIMG($(this), productListImg1);
			});
		});
		$('.support-wrap .model-information-wrap .model-info-box .image img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				srcErrorIMG($(this), productListImg1);
			});
		});
		$('.support-wrap .step-in-form .step-cluster .select-product .model-view-image .image-box img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				srcErrorIMG($(this), productListImg1);
			});
		});
		$('.request-repair-completion .table-view  td img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				srcErrorIMG($(this), productListImg3);
			});
		});

		// CS > Track Repair > List
		$('.support-wrap .track-repair-list .result-area table img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				srcErrorIMG($(this), productListImg3);
			});
		});
		$('.support-wrap .repair-info-wrap table img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				srcErrorIMG($(this), productListImg3);
			});
		});

		// CS > Email
		$('.support-wrap .email-common .your-product .model-image-box .model-view-image .image-box img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				srcErrorIMG($(this), productListImg1);
			});
		});
		$('.support-wrap .email-common .your-product .select-product .my-Products .product-type .item .visual img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				if($(this).hasClass('mobile')) srcErrorIMG($(this), productListImg2);
				else srcErrorIMG($(this), productListImg1);
			});
		});

		// CS > mylg > request repair list
		$('.support-wrap .request-repair-list .result-area table img').each(function() {
			$(this).off('error').on('error', function() {
				$(this).off('error');
				srcErrorIMG($(this), productListImg3);
			});
		});

	}
	bindImgError();

	$('img.lazyload').on('load', function() {
		$(this).attr('data-loaded', true);
	});

// lazysizes - v4.1.4
	!function(a,b){var c=b(a,a.document);a.lazySizes=c,"object"==typeof module&&module.exports&&(module.exports=c)}(window,function(a,b){"use strict";if(b.getElementsByClassName){var c,d,e=b.documentElement,f=a.Date,g=a.HTMLPictureElement,h="addEventListener",i="getAttribute",j=a[h],k=a.setTimeout,l=a.requestAnimationFrame||k,m=a.requestIdleCallback,n=/^picture$/i,o=["load","error","lazyincluded","_lazyloaded"],p={},q=Array.prototype.forEach,r=function(a,b){return p[b]||(p[b]=new RegExp("(\\s|^)"+b+"(\\s|$)")),p[b].test(a[i]("class")||"")&&p[b]},s=function(a,b){r(a,b)||a.setAttribute("class",(a[i]("class")||"").trim()+" "+b)},t=function(a,b){var c;(c=r(a,b))&&a.setAttribute("class",(a[i]("class")||"").replace(c," "))},u=function(a,b,c){var d=c?h:"removeEventListener";c&&u(a,b),o.forEach(function(c){a[d](c,b)})},v=function(a,d,e,f,g){var h=b.createEvent("Event");return e||(e={}),e.instance=c,h.initEvent(d,!f,!g),h.detail=e,a.dispatchEvent(h),h},w=function(b,c){var e;!g&&(e=a.picturefill||d.pf)?(c&&c.src&&!b[i]("srcset")&&b.setAttribute("srcset",c.src),e({reevaluate:!0,elements:[b]})):c&&c.src&&(b.src=c.src)},x=function(a,b){return(getComputedStyle(a,null)||{})[b]},y=function(a,b,c){for(c=c||a.offsetWidth;c<d.minSize&&b&&!a._lazysizesWidth;)c=b.offsetWidth,b=b.parentNode;return c},z=function(){var a,c,d=[],e=[],f=d,g=function(){var b=f;for(f=d.length?e:d,a=!0,c=!1;b.length;)b.shift()();a=!1},h=function(d,e){a&&!e?d.apply(this,arguments):(f.push(d),c||(c=!0,(b.hidden?k:l)(g)))};return h._lsFlush=g,h}(),A=function(a,b){return b?function(){z(a)}:function(){var b=this,c=arguments;z(function(){a.apply(b,c)})}},B=function(a){var b,c=0,e=d.throttleDelay,g=d.ricTimeout,h=function(){b=!1,c=f.now(),a()},i=m&&g>49?function(){m(h,{timeout:g}),g!==d.ricTimeout&&(g=d.ricTimeout)}:A(function(){k(h)},!0);return function(a){var d;(a=a===!0)&&(g=33),b||(b=!0,d=e-(f.now()-c),0>d&&(d=0),a||9>d?i():k(i,d))}},C=function(a){var b,c,d=99,e=function(){b=null,a()},g=function(){var a=f.now()-c;d>a?k(g,d-a):(m||e)(e)};return function(){c=f.now(),b||(b=k(g,d))}};!function(){var b,c={lazyClass:"lazyload",loadedClass:"lazyloaded",loadingClass:"lazyloading",preloadClass:"lazypreload",errorClass:"lazyerror",autosizesClass:"lazyautosizes",srcAttr:"data-src",srcsetAttr:"data-srcset",sizesAttr:"data-sizes",minSize:40,customMedia:{},init:!0,expFactor:1.5,hFac:.8,loadMode:2,loadHidden:!0,ricTimeout:0,throttleDelay:125};d=a.lazySizesConfig||a.lazysizesConfig||{};for(b in c)b in d||(d[b]=c[b]);a.lazySizesConfig=d,k(function(){d.init&&F()})}();var D=function(){var g,l,m,o,p,y,D,F,G,H,I,J,K,L,M=/^img$/i,N=/^iframe$/i,O="onscroll"in a&&!/(gle|ing)bot/.test(navigator.userAgent),P=0,Q=0,R=0,S=-1,T=function(a){R--,a&&a.target&&u(a.target,T),(!a||0>R||!a.target)&&(R=0)},U=function(a,c){var d,f=a,g="hidden"==x(b.body,"visibility")||"hidden"!=x(a.parentNode,"visibility")&&"hidden"!=x(a,"visibility");for(F-=c,I+=c,G-=c,H+=c;g&&(f=f.offsetParent)&&f!=b.body&&f!=e;)g=(x(f,"opacity")||1)>0,g&&"visible"!=x(f,"overflow")&&(d=f.getBoundingClientRect(),g=H>d.left&&G<d.right&&I>d.top-1&&F<d.bottom+1);return g},V=function(){var a,f,h,j,k,m,n,p,q,r=c.elements;if((o=d.loadMode)&&8>R&&(a=r.length)){f=0,S++,null==K&&("expand"in d||(d.expand=e.clientHeight>500&&e.clientWidth>500?500:370),J=d.expand,K=J*d.expFactor),K>Q&&1>R&&S>2&&o>2&&!b.hidden?(Q=K,S=0):Q=o>1&&S>1&&6>R?J:P;for(;a>f;f++)if(r[f]&&!r[f]._lazyRace)if(O)if((p=r[f][i]("data-expand"))&&(m=1*p)||(m=Q),q!==m&&(y=innerWidth+m*L,D=innerHeight+m,n=-1*m,q=m),h=r[f].getBoundingClientRect(),(I=h.bottom)>=n&&(F=h.top)<=D&&(H=h.right)>=n*L&&(G=h.left)<=y&&(I||H||G||F)&&(d.loadHidden||"hidden"!=x(r[f],"visibility"))&&(l&&3>R&&!p&&(3>o||4>S)||U(r[f],m))){if(ba(r[f]),k=!0,R>9)break}else!k&&l&&!j&&4>R&&4>S&&o>2&&(g[0]||d.preloadAfterLoad)&&(g[0]||!p&&(I||H||G||F||"auto"!=r[f][i](d.sizesAttr)))&&(j=g[0]||r[f]);else ba(r[f]);j&&!k&&ba(j)}},W=B(V),X=function(a){s(a.target,d.loadedClass),t(a.target,d.loadingClass),u(a.target,Z),v(a.target,"lazyloaded")},Y=A(X),Z=function(a){Y({target:a.target})},$=function(a,b){try{a.contentWindow.location.replace(b)}catch(c){a.src=b}},_=function(a){var b,c=a[i](d.srcsetAttr);(b=d.customMedia[a[i]("data-media")||a[i]("media")])&&a.setAttribute("media",b),c&&a.setAttribute("srcset",c)},aa=A(function(a,b,c,e,f){var g,h,j,l,o,p;(o=v(a,"lazybeforeunveil",b)).defaultPrevented||(e&&(c?s(a,d.autosizesClass):a.setAttribute("sizes",e)),h=a[i](d.srcsetAttr),g=a[i](d.srcAttr),f&&(j=a.parentNode,l=j&&n.test(j.nodeName||"")),p=b.firesLoad||"src"in a&&(h||g||l),o={target:a},p&&(u(a,T,!0),clearTimeout(m),m=k(T,2500),s(a,d.loadingClass),u(a,Z,!0)),l&&q.call(j.getElementsByTagName("source"),_),h?a.setAttribute("srcset",h):g&&!l&&(N.test(a.nodeName)?$(a,g):a.src=g),f&&(h||l)&&w(a,{src:g})),a._lazyRace&&delete a._lazyRace,t(a,d.lazyClass),z(function(){(!p||a.complete&&a.naturalWidth>1)&&(p?T(o):R--,X(o))},!0)}),ba=function(a){var b,c=M.test(a.nodeName),e=c&&(a[i](d.sizesAttr)||a[i]("sizes")),f="auto"==e;(!f&&l||!c||!a[i]("src")&&!a.srcset||a.complete||r(a,d.errorClass)||!r(a,d.lazyClass))&&(b=v(a,"lazyunveilread").detail,f&&E.updateElem(a,!0,a.offsetWidth),a._lazyRace=!0,R++,aa(a,b,f,e,c))},ca=function(){if(!l){if(f.now()-p<999)return void k(ca,999);var a=C(function(){d.loadMode=3,W()});l=!0,d.loadMode=3,W(),j("scroll",function(){3==d.loadMode&&(d.loadMode=2),a()},!0)}};return{_:function(){p=f.now(),c.elements=b.getElementsByClassName(d.lazyClass),g=b.getElementsByClassName(d.lazyClass+" "+d.preloadClass),L=d.hFac,j("scroll",W,!0),j("resize",W,!0),a.MutationObserver?new MutationObserver(W).observe(e,{childList:!0,subtree:!0,attributes:!0}):(e[h]("DOMNodeInserted",W,!0),e[h]("DOMAttrModified",W,!0),setInterval(W,999)),j("hashchange",W,!0),["focus","mouseover","click","load","transitionend","animationend","webkitAnimationEnd"].forEach(function(a){b[h](a,W,!0)}),/d$|^c/.test(b.readyState)?ca():(j("load",ca),b[h]("DOMContentLoaded",W),k(ca,2e4)),c.elements.length?(V(),z._lsFlush()):W()},checkElems:W,unveil:ba}}(),E=function(){var a,c=A(function(a,b,c,d){var e,f,g;if(a._lazysizesWidth=d,d+="px",a.setAttribute("sizes",d),n.test(b.nodeName||""))for(e=b.getElementsByTagName("source"),f=0,g=e.length;g>f;f++)e[f].setAttribute("sizes",d);c.detail.dataAttr||w(a,c.detail)}),e=function(a,b,d){var e,f=a.parentNode;f&&(d=y(a,f,d),e=v(a,"lazybeforesizes",{width:d,dataAttr:!!b}),e.defaultPrevented||(d=e.detail.width,d&&d!==a._lazysizesWidth&&c(a,f,e,d)))},f=function(){var b,c=a.length;if(c)for(b=0;c>b;b++)e(a[b])},g=C(f);return{_:function(){a=b.getElementsByClassName(d.autosizesClass),j("resize",g)},checkElems:g,updateElem:e}}(),F=function(){F.i||(F.i=!0,E._(),D._())};return c={cfg:d,autoSizer:E,loader:D,init:F,uP:w,aC:s,rC:t,hC:r,fire:v,gW:y,rAF:z}}});

// Slick - 1.8.1 
/*
	Last Modified Date : 2019-11-22
*/
/* LGECI-261 20201209 edit *//* LGECI-261 20201209 edit */
! function(i) {
	"use strict";
	"function" == typeof define && define.amd ? define(["jquery"], i) : "undefined" != typeof exports ? module.exports = i(require("jquery")) : i(jQuery)
}(function(i) {
	"use strict";
	var e = window.Slick || {};
	(e = function() {
		var e = 0;
		return function(t, o) {
			var s, n = this;
			n.defaults = {
				accessibility: !0,
				adaptiveHeight: !1,
				appendArrows: i(t),
				appendDots: i(t),
				arrows: !0,
				asNavFor: null,
				prevArrow: '<button class="slick-prev" aria-label="Previous" type="button"><span class="visually-hidden">Previous</span></button>',
				nextArrow: '<button class="slick-next" aria-label="Next" type="button"><span class="visually-hidden">Next</span></button>',
				autoplay: !1,
				autoplaySpeed: 3e3,
				centerMode: !1,
				centerPadding: "50px",
				cssEase: "ease",
				customPaging: function(e, t) {
					return i('<button type="button" />').text(t + 1)
				},
				dots: !1,
				dotsClass: "slick-dots",
				draggable: !0,
				easing: "linear",
				edgeFriction: .35,
				fade: !1,
				focusOnSelect: !1,
				focusOnChange: !1,
				infinite: !0,
				initialSlide: 0,
				lazyLoad: "ondemand",
				mobileFirst: !1,
				pauseOnHover: !0,
				pauseOnFocus: !0,
				pauseOnDotsHover: !1,
				respondTo: "window",
				responsive: null,
				rows: 1,
				rtl: !1,
				listStyle: !1, // WA-Common-Slick
				slide: "",
				slidesPerRow: 1,
				slidesToShow: 1,
				slidesToScroll: 1,
				speed: 500,
				swipe: !0,
				swipeToSlide: !1,
				touchMove: !0,
				touchThreshold: 5,
				useCSS: !0,
				useTransform: !0,
				variableWidth: !1,
				vertical: !1,
				verticalSwiping: !1,
				waitForAnimate: !0,
				zIndex: 1e3
			}, n.initials = {
				animating: !1,
				dragging: !1,
				autoPlayTimer: null,
				currentDirection: 0,
				currentLeft: null,
				currentSlide: 0,
				direction: 1,
				$dots: null,
				listWidth: null,
				listHeight: null,
				loadIndex: 0,
				$nextArrow: null,
				$prevArrow: null,
				scrolling: !1,
				slideCount: null,
				slideWidth: null,
				$slideTrack: null,
				$slides: null,
				sliding: !1,
				slideOffset: 0,
				swipeLeft: null,
				swiping: !1,
				$list: null,
				touchObject: {},
				transformsEnabled: !1,
				unslicked: !1
			}, i.extend(n, n.initials), n.activeBreakpoint = null, n.animType = null, n.animProp = null, n.breakpoints = [], n.breakpointSettings = [], n.cssTransitions = !1, n.focussed = !1, n.interrupted = !1, n.hidden = "hidden", n.paused = !0, n.positionProp = null, n.respondTo = null, n.rowCount = 1, n.shouldClick = !0, n.$slider = i(t), n.$slidesCache = null, n.transformType = null, n.transitionType = null, n.visibilityChange = "visibilitychange", n.windowWidth = 0, n.windowTimer = null, s = i(t).data("slick") || {}, n.options = i.extend({}, n.defaults, o, s), n.currentSlide = n.options.initialSlide, n.originalSettings = n.options, void 0 !== document.mozHidden ? (n.hidden = "mozHidden", n.visibilityChange = "mozvisibilitychange") : void 0 !== document.webkitHidden && (n.hidden = "webkitHidden", n.visibilityChange = "webkitvisibilitychange"), n.autoPlay = i.proxy(n.autoPlay, n), n.autoPlayClear = i.proxy(n.autoPlayClear, n), n.autoPlayIterator = i.proxy(n.autoPlayIterator, n), n.changeSlide = i.proxy(n.changeSlide, n), n.clickHandler = i.proxy(n.clickHandler, n), n.selectHandler = i.proxy(n.selectHandler, n), n.setPosition = i.proxy(n.setPosition, n), n.swipeHandler = i.proxy(n.swipeHandler, n), n.dragHandler = i.proxy(n.dragHandler, n), n.keyHandler = i.proxy(n.keyHandler, n), n.instanceUid = e++, n.htmlExpr = /^(?:\s*(<[\w\W]+>)[^>]*)$/, n.registerBreakpoints(), n.init(!0)
		}
	}()).prototype.activateADA = function() {
		this.$slideTrack.find(".slick-active").attr({
			"aria-hidden": "false"
		}).find("a:not(.required-tabindex), input, button, select").attr({ // WA-Common-Slick
			tabindex: "0"
		})
	}, e.prototype.addSlide = e.prototype.slickAdd = function(e, t, o) {
		var s = this;
		if ("boolean" == typeof t) o = t, t = null;
		else if (t < 0 || t >= s.slideCount) return !1;
		s.unload(), "number" == typeof t ? 0 === t && 0 === s.$slides.length ? i(e).appendTo(s.$slideTrack) : o ? i(e).insertBefore(s.$slides.eq(t)) : i(e).insertAfter(s.$slides.eq(t)) : !0 === o ? i(e).prependTo(s.$slideTrack) : i(e).appendTo(s.$slideTrack), s.$slides = s.$slideTrack.children(this.options.slide), s.$slideTrack.children(this.options.slide).detach(), s.$slideTrack.append(s.$slides), s.$slides.each(function(e, t) {
			i(t).attr("data-slick-index", e)
		}), s.$slidesCache = s.$slides, s.reinit()
	}, e.prototype.animateHeight = function() {
		var i = this;
		if (1 === i.options.slidesToShow && !0 === i.options.adaptiveHeight && !1 === i.options.vertical) {
			var e = i.$slides.eq(i.currentSlide).outerHeight(!0);
			i.$list.animate({
				height: e
			}, i.options.speed)
		}
	}, e.prototype.animateSlide = function(e, t) {
		var o = {},
			s = this;
		s.animateHeight(), !0 === s.options.rtl && !1 === s.options.vertical && (e = -e), !1 === s.transformsEnabled ? !1 === s.options.vertical ? s.$slideTrack.animate({
			left: e
		}, s.options.speed, s.options.easing, t) : s.$slideTrack.animate({
			top: e
		}, s.options.speed, s.options.easing, t) : !1 === s.cssTransitions ? (!0 === s.options.rtl && (s.currentLeft = -s.currentLeft), i({
			animStart: s.currentLeft
		}).animate({
			animStart: e
		}, {
			duration: s.options.speed,
			easing: s.options.easing,
			step: function(i) {
				i = Math.ceil(i), !1 === s.options.vertical ? (o[s.animType] = "translate(" + i + "px, 0px)", s.$slideTrack.css(o)) : (o[s.animType] = "translate(0px," + i + "px)", s.$slideTrack.css(o))
			},
			complete: function() {
				t && t.call()
			}
		})) : (s.applyTransition(), e = Math.ceil(e), !1 === s.options.vertical ? o[s.animType] = "translate3d(" + e + "px, 0px, 0px)" : o[s.animType] = "translate3d(0px," + e + "px, 0px)", s.$slideTrack.css(o), t && setTimeout(function() {
			s.disableTransition(), t.call()
		}, s.options.speed))
	}, e.prototype.getNavTarget = function() {
		var e = this,
			t = e.options.asNavFor;
		return t && null !== t && (t = i(t).not(e.$slider)), t
	}, e.prototype.asNavFor = function(e) {
		var t = this.getNavTarget();
		null !== t && "object" == typeof t && t.each(function() {
			var t = i(this).slick("getSlick");
			t.unslicked || t.slideHandler(e, !0)
		})
	}, e.prototype.applyTransition = function(i) {
		var e = this,
			t = {};
		!1 === e.options.fade ? t[e.transitionType] = e.transformType + " " + e.options.speed + "ms " + e.options.cssEase : t[e.transitionType] = "opacity " + e.options.speed + "ms " + e.options.cssEase, !1 === e.options.fade ? e.$slideTrack.css(t) : e.$slides.eq(i).css(t)
	}, e.prototype.autoPlay = function() {
		var i = this;
		i.autoPlayClear(), i.slideCount > i.options.slidesToShow && (i.autoPlayTimer = setInterval(i.autoPlayIterator, i.options.autoplaySpeed))
	}, e.prototype.autoPlayClear = function() {
		var i = this;
		i.autoPlayTimer && clearInterval(i.autoPlayTimer)
	}, e.prototype.autoPlayIterator = function() {
		var i = this,
			e = i.currentSlide + i.options.slidesToScroll;
		i.paused || i.interrupted || i.focussed || (!1 === i.options.infinite && (1 === i.direction && i.currentSlide + 1 === i.slideCount - 1 ? i.direction = 0 : 0 === i.direction && (e = i.currentSlide - i.options.slidesToScroll, i.currentSlide - 1 == 0 && (i.direction = 1))), i.slideHandler(e))
	}, e.prototype.buildArrows = function() {
		var e = this;
		!0 === e.options.arrows && (e.$prevArrow = i(e.options.prevArrow).addClass("slick-arrow"), e.$nextArrow = i(e.options.nextArrow).addClass("slick-arrow"), e.slideCount > e.options.slidesToShow ? (e.$prevArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"), e.$nextArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"), e.htmlExpr.test(e.options.prevArrow) && e.$prevArrow.prependTo(e.options.appendArrows), e.htmlExpr.test(e.options.nextArrow) && e.$nextArrow.appendTo(e.options.appendArrows), !0 !== e.options.infinite && e.$prevArrow.addClass("slick-disabled").attr("aria-disabled", "true").attr("disabled", "true")) : e.$prevArrow.add(e.$nextArrow).addClass("slick-hidden").attr({
			"aria-disabled": "true",
			"disabled": "true",
			"tabindex" : "-1" //- WA-Common-Slick
		}))
	}, e.prototype.buildDots = function() {
		var e, t, o = this;
		if (!0 === o.options.dots) {
			for (o.$slider.addClass("slick-dotted"), t = i("<ul />").addClass(o.options.dotsClass), e = 0; e <= o.getDotCount(); e += 1) t.append(i("<li />").append(o.options.customPaging.call(this, o, e)));
			o.$dots = t.appendTo(o.options.appendDots), o.$dots.find("li").first().addClass("slick-active")
		}
	}, e.prototype.buildOut = function() {
		var e = this;
		/* WA-Common-Slick :  */
		var html = e.options.listStyle ? '<ul class="slick-track"/>' : '<div class="slick-track"/>';
		//var html2 = (e.$slider.get(0).tagName=='UL') ? '<li class="slick-list"/>' : '<div class="slick-list"/>';
		e.$slides = e.$slider.children(e.options.slide + ":not(.slick-cloned)").addClass("slick-slide"), e.slideCount = e.$slides.length, e.$slides.each(function(e, t) {
			i(t).attr("data-slick-index", e).data("originalStyling", i(t).attr("style") || "")
		}), e.$slider.addClass("slick-slider"), e.$slideTrack = 0 === e.slideCount ? i(html).appendTo(e.$slider) : e.$slides.wrapAll(html).parent(), e.$list = e.$slideTrack.wrap('<div class="slick-list"/>').parent(), e.$slideTrack.css("opacity", 0), !0 !== e.options.centerMode && !0 !== e.options.swipeToSlide || (e.options.slidesToScroll = 1), i("img[data-lazy]", e.$slider).not("[src]").addClass("slick-loading"), e.setupInfinite(), e.buildArrows(), e.buildDots(), e.updateDots(), e.setSlideClasses("number" == typeof e.currentSlide ? e.currentSlide : 0), !0 === e.options.draggable && e.$list.addClass("draggable")
		/* WA-Common-Slick :  */
	}, e.prototype.buildRows = function() {
		var i, e, t, o, s, n, r, l = this;
		if (o = document.createDocumentFragment(), n = l.$slider.children(), l.options.rows > 1) {
			for (r = l.options.slidesPerRow * l.options.rows, s = Math.ceil(n.length / r), i = 0; i < s; i++) {
				var d = document.createElement("div");
				for (e = 0; e < l.options.rows; e++) {
					var a = document.createElement("div");
					for (t = 0; t < l.options.slidesPerRow; t++) {
						var c = i * r + (e * l.options.slidesPerRow + t);
						n.get(c) && a.appendChild(n.get(c))
					}
					d.appendChild(a)
				}
				o.appendChild(d)
			}
			l.$slider.empty().append(o), l.$slider.children().children().children().css({
				width: 100 / l.options.slidesPerRow + "%",
				display: "inline-block"
			})
		}
	}, e.prototype.checkResponsive = function(e, t) {
		var o, s, n, r = this,
			l = !1,
			d = r.$slider.width(),
			a = window.innerWidth || i(window).width();
		if ("window" === r.respondTo ? n = a : "slider" === r.respondTo ? n = d : "min" === r.respondTo && (n = Math.min(a, d)), r.options.responsive && r.options.responsive.length && null !== r.options.responsive) {
			s = null;
			for (o in r.breakpoints) r.breakpoints.hasOwnProperty(o) && (!1 === r.originalSettings.mobileFirst ? n < r.breakpoints[o] && (s = r.breakpoints[o]) : n > r.breakpoints[o] && (s = r.breakpoints[o]));
			null !== s ? null !== r.activeBreakpoint ? (s !== r.activeBreakpoint || t) && (r.activeBreakpoint = s, "unslick" === r.breakpointSettings[s] ? r.unslick(s) : (r.options = i.extend({}, r.originalSettings, r.breakpointSettings[s]), !0 === e && (r.currentSlide = r.options.initialSlide), r.refresh(e)), l = s) : (r.activeBreakpoint = s, "unslick" === r.breakpointSettings[s] ? r.unslick(s) : (r.options = i.extend({}, r.originalSettings, r.breakpointSettings[s]), !0 === e && (r.currentSlide = r.options.initialSlide), r.refresh(e)), l = s) : null !== r.activeBreakpoint && (r.activeBreakpoint = null, r.options = r.originalSettings, !0 === e && (r.currentSlide = r.options.initialSlide), r.refresh(e), l = s), e || !1 === l || r.$slider.trigger("breakpoint", [r, l])
		}
	}, e.prototype.changeSlide = function(e, t) {
		var o, s, n, r = this,
			l = i(e.currentTarget);
		switch (l.is("a") && e.preventDefault(), l.is("li") || (l = l.closest("li")), n = r.slideCount % r.options.slidesToScroll != 0, o = n ? 0 : (r.slideCount - r.currentSlide) % r.options.slidesToScroll, e.data.message) {
			case "previous":
				s = 0 === o ? r.options.slidesToScroll : r.options.slidesToShow - o, r.slideCount > r.options.slidesToShow && r.slideHandler(r.currentSlide - s, !1, t);
				break;
			case "next":
				s = 0 === o ? r.options.slidesToScroll : o, r.slideCount > r.options.slidesToShow && r.slideHandler(r.currentSlide + s, !1, t);
				break;
			case "index":
				var d = 0 === e.data.index ? 0 : e.data.index || l.index() * r.options.slidesToScroll;
				r.slideHandler(r.checkNavigable(d), !1, t), l.children().trigger("focus");
				break;
			default:
				return
		}
	}, e.prototype.checkNavigable = function(i) {
		var e, t;
		if (e = this.getNavigableIndexes(), t = 0, i > e[e.length - 1]) i = e[e.length - 1];
		else
			for (var o in e) {
				if (i < e[o]) {
					i = t;
					break
				}
				t = e[o]
			}
		return i
	}, e.prototype.cleanUpEvents = function() {
		var e = this;
		e.options.dots && null !== e.$dots && (i("li", e.$dots).off("click.slick", e.changeSlide).off("mouseenter.slick", i.proxy(e.interrupt, e, !0)).off("mouseleave.slick", i.proxy(e.interrupt, e, !1)), !0 === e.options.accessibility && e.$dots.off("keydown.slick", e.keyHandler)), e.$slider.off("focus.slick blur.slick"), !0 === e.options.arrows && e.slideCount > e.options.slidesToShow && (e.$prevArrow && e.$prevArrow.off("click.slick", e.changeSlide), e.$nextArrow && e.$nextArrow.off("click.slick", e.changeSlide), !0 === e.options.accessibility && (e.$prevArrow && e.$prevArrow.off("keydown.slick", e.keyHandler), e.$nextArrow && e.$nextArrow.off("keydown.slick", e.keyHandler))), e.$list.off("touchstart.slick mousedown.slick", e.swipeHandler), e.$list.off("touchmove.slick mousemove.slick", e.swipeHandler), e.$list.off("touchend.slick mouseup.slick", e.swipeHandler), e.$list.off("touchcancel.slick mouseleave.slick", e.swipeHandler), e.$list.off("click.slick", e.clickHandler), i(document).off(e.visibilityChange, e.visibility), e.cleanUpSlideEvents(), !0 === e.options.accessibility && e.$list.off("keydown.slick", e.keyHandler), !0 === e.options.focusOnSelect && i(e.$slideTrack).children().off("click.slick", e.selectHandler), i(window).off("orientationchange.slick.slick-" + e.instanceUid, e.orientationChange), i(window).off("resize.slick.slick-" + e.instanceUid, e.resize), i("[draggable!=true]", e.$slideTrack).off("dragstart", e.preventDefault), i(window).off("load.slick.slick-" + e.instanceUid, e.setPosition)
	}, e.prototype.cleanUpSlideEvents = function() {
		var e = this;
		e.$list.off("mouseenter.slick", i.proxy(e.interrupt, e, !0)), e.$list.off("mouseleave.slick", i.proxy(e.interrupt, e, !1))
	}, e.prototype.cleanUpRows = function() {
		var i, e = this;
		e.options.rows > 1 && ((i = e.$slides.children().children()).removeAttr("style"), e.$slider.empty().append(i))
	}, e.prototype.clickHandler = function(i) {
		!1 === this.shouldClick && (i.stopImmediatePropagation(), i.stopPropagation(), i.preventDefault())
	}, e.prototype.destroy = function(e) {
		var t = this;
		// WA-Common-Slick 
		t.autoPlayClear(),
		t.touchObject = {},
		t.cleanUpEvents(),
		i(".slick-cloned", t.$slider).detach(),
		t.$dots && t.$dots.remove(),
		t.$prevArrow && t.$prevArrow.length && (t.$prevArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex disabled").css("display", ""),
		t.htmlExpr.test(t.options.prevArrow) && t.$prevArrow.remove()),
		t.$nextArrow && t.$nextArrow.length && (t.$nextArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex disabled").css("display", ""),
		t.htmlExpr.test(t.options.nextArrow) && t.$nextArrow.remove()),
		t.$slides && (t.$slides.removeClass("slick-slide slick-active slick-center slick-visible slick-current").removeAttr("aria-hidden").removeAttr("data-slick-index").each(function() {
			i(this).attr("style", i(this).data("originalStyling"))
		}),
		t.$slideTrack.children(this.options.slide).detach(),
		t.$slideTrack.detach(),
		t.$list.detach(),
		t.$slider.append(t.$slides)),
		t.cleanUpRows(),
		t.$slider.removeClass("slick-slider"),
		t.$slider.removeClass("slick-initialized"),
		t.$slider.removeClass("slick-dotted");
		if(t.options.listStyle && t.$slider.data('origin-tagname') != 'UL') {
			t.$slider.find('>li').each(function() {
				var className=$(this).attr('class');
				$(this).replaceWith('<div class="'+className+'">' + $(this).html() +'</div>')
			});
		}
		if (t.$slider.data('origin-tagname') == 'UL') {
			var html = t.$slider.html();
			//console.log(html);
			t.$slider.html('<ul></ul>').find('ul').html(html);
		}
		t.unslicked = !0,
		e || t.$slider.trigger("destroy", [t])
	}, e.prototype.disableTransition = function(i) {
		var e = this,
			t = {};
		t[e.transitionType] = "", !1 === e.options.fade ? e.$slideTrack.css(t) : e.$slides.eq(i).css(t)
	}, e.prototype.fadeSlide = function(i, e) {
		var t = this;
		!1 === t.cssTransitions ? (t.$slides.eq(i).css({
			zIndex: t.options.zIndex
		}), t.$slides.eq(i).animate({
			opacity: 1
		}, t.options.speed, t.options.easing, e)) : (t.applyTransition(i), t.$slides.eq(i).css({
			opacity: 1,
			zIndex: t.options.zIndex
		}), e && setTimeout(function() {
			t.disableTransition(i), e.call()
		}, t.options.speed))
	}, e.prototype.fadeSlideOut = function(i) {
		var e = this;
		!1 === e.cssTransitions ? e.$slides.eq(i).animate({
			opacity: 0,
			zIndex: e.options.zIndex - 2
		}, e.options.speed, e.options.easing) : (e.applyTransition(i), e.$slides.eq(i).css({
			opacity: 0,
			zIndex: e.options.zIndex - 2
		}))
	}, e.prototype.filterSlides = e.prototype.slickFilter = function(i) {
		var e = this;
		null !== i && (e.$slidesCache = e.$slides, e.unload(), e.$slideTrack.children(this.options.slide).detach(), e.$slidesCache.filter(i).appendTo(e.$slideTrack), e.reinit())
	}, e.prototype.focusHandler = function() {
		var e = this;
		e.$slider.off("focus.slick blur.slick").on("focus.slick blur.slick", "*", function(t) {
			t.stopImmediatePropagation();
			var o = i(this);
			setTimeout(function() {
				e.options.pauseOnFocus && (e.focussed = o.is(":focus"), e.autoPlay())
			}, 0)
		})
	}, e.prototype.getCurrent = e.prototype.slickCurrentSlide = function() {
		return this.currentSlide
	}, e.prototype.getDotCount = function() {
		var i = this,
			e = 0,
			t = 0,
			o = 0;
		if (!0 === i.options.infinite)
			if (i.slideCount <= i.options.slidesToShow) ++o;
			else
				for (; e < i.slideCount;) ++o, e = t + i.options.slidesToScroll, t += i.options.slidesToScroll <= i.options.slidesToShow ? i.options.slidesToScroll : i.options.slidesToShow;
		else if (!0 === i.options.centerMode) o = i.slideCount;
		else if (i.options.asNavFor)
			for (; e < i.slideCount;) ++o, e = t + i.options.slidesToScroll, t += i.options.slidesToScroll <= i.options.slidesToShow ? i.options.slidesToScroll : i.options.slidesToShow;
		else o = 1 + Math.ceil((i.slideCount - i.options.slidesToShow) / i.options.slidesToScroll);
		return o - 1
	}, e.prototype.getLeft = function(i) {
		var e, t, o, s, n = this,
			r = 0;
		return n.slideOffset = 0, t = n.$slides.first().outerHeight(!0), !0 === n.options.infinite ? (n.slideCount > n.options.slidesToShow && (n.slideOffset = n.slideWidth * n.options.slidesToShow * -1, s = -1, !0 === n.options.vertical && !0 === n.options.centerMode && (2 === n.options.slidesToShow ? s = -1.5 : 1 === n.options.slidesToShow && (s = -2)), r = t * n.options.slidesToShow * s), n.slideCount % n.options.slidesToScroll != 0 && i + n.options.slidesToScroll > n.slideCount && n.slideCount > n.options.slidesToShow && (i > n.slideCount ? (n.slideOffset = (n.options.slidesToShow - (i - n.slideCount)) * n.slideWidth * -1, r = (n.options.slidesToShow - (i - n.slideCount)) * t * -1) : (n.slideOffset = n.slideCount % n.options.slidesToScroll * n.slideWidth * -1, r = n.slideCount % n.options.slidesToScroll * t * -1))) : i + n.options.slidesToShow > n.slideCount && (n.slideOffset = (i + n.options.slidesToShow - n.slideCount) * n.slideWidth, r = (i + n.options.slidesToShow - n.slideCount) * t), n.slideCount <= n.options.slidesToShow && (n.slideOffset = 0, r = 0), !0 === n.options.centerMode && n.slideCount <= n.options.slidesToShow ? n.slideOffset = n.slideWidth * Math.floor(n.options.slidesToShow) / 2 - n.slideWidth * n.slideCount / 2 : !0 === n.options.centerMode && !0 === n.options.infinite ? n.slideOffset += n.slideWidth * Math.floor(n.options.slidesToShow / 2) - n.slideWidth : !0 === n.options.centerMode && (n.slideOffset = 0, n.slideOffset += n.slideWidth * Math.floor(n.options.slidesToShow / 2)), e = !1 === n.options.vertical ? i * n.slideWidth * -1 + n.slideOffset : i * t * -1 + r, !0 === n.options.variableWidth && (o = n.slideCount <= n.options.slidesToShow || !1 === n.options.infinite ? n.$slideTrack.children(".slick-slide").eq(i) : n.$slideTrack.children(".slick-slide").eq(i + n.options.slidesToShow), e = !0 === n.options.rtl ? o[0] ? -1 * (n.$slideTrack.width() - o[0].offsetLeft - o.width()) : 0 : o[0] ? -1 * o[0].offsetLeft : 0, !0 === n.options.centerMode && (o = n.slideCount <= n.options.slidesToShow || !1 === n.options.infinite ? n.$slideTrack.children(".slick-slide").eq(i) : n.$slideTrack.children(".slick-slide").eq(i + n.options.slidesToShow + 1), e = !0 === n.options.rtl ? o[0] ? -1 * (n.$slideTrack.width() - o[0].offsetLeft - o.width()) : 0 : o[0] ? -1 * o[0].offsetLeft : 0, e += (n.$list.width() - o.outerWidth()) / 2)), e
	}, e.prototype.getOption = e.prototype.slickGetOption = function(i) {
		return this.options[i]
	}, e.prototype.getNavigableIndexes = function() {
		var i, e = this,
			t = 0,
			o = 0,
			s = [];
		for (!1 === e.options.infinite ? i = e.slideCount : (t = -1 * e.options.slidesToScroll, o = -1 * e.options.slidesToScroll, i = 2 * e.slideCount); t < i;) s.push(t), t = o + e.options.slidesToScroll, o += e.options.slidesToScroll <= e.options.slidesToShow ? e.options.slidesToScroll : e.options.slidesToShow;
		return s
	}, e.prototype.getSlick = function() {
		return this
	}, e.prototype.getSlideCount = function() {
		var e, t, o = this;
		return t = !0 === o.options.centerMode ? o.slideWidth * Math.floor(o.options.slidesToShow / 2) : 0, !0 === o.options.swipeToSlide ? (o.$slideTrack.find(".slick-slide").each(function(s, n) {
			if (n.offsetLeft - t + i(n).outerWidth() / 2 > -1 * o.swipeLeft) return e = n, !1
		}), Math.abs(i(e).attr("data-slick-index") - o.currentSlide) || 1) : o.options.slidesToScroll
	}, e.prototype.goTo = e.prototype.slickGoTo = function(i, e) {
		this.changeSlide({
			data: {
				message: "index",
				index: parseInt(i)
			}
		}, e)
	}, e.prototype.init = function(e) {
		var t = this;
		/* WA-Common-Slick :  */
		if (t.$slider.find('>ul').length>0) {
			t.$slider.html(t.$slider.find('>ul').html());
			t.$slider.data('origin-tagname', 'UL');
		} else {
			t.$slider.data('origin-tagname', '');
		}
		if(t.options.listStyle) { //  && t.$slider.find('.slick-track').length>0 && t.$slider.find('.slick-track').get(0).tagName=='UL'
			t.$slider.find('> div, >li').each(function() {
				var className=$(this).attr('class');
				$(this).replaceWith('<li class="'+className+'">' + $(this).html() +'</li>')
			});
		}
		/* WA-Common-Slick : */
		i(t.$slider).hasClass("slick-initialized") || (i(t.$slider).addClass("slick-initialized"), t.buildRows(), t.buildOut(), t.setProps(), t.startLoad(), t.loadSlider(), t.initializeEvents(), t.updateArrows(), t.updateDots(), t.checkResponsive(!0), t.focusHandler()), e && t.$slider.trigger("init", [t]), !0 === t.options.accessibility && t.initADA(), t.options.autoplay && (t.paused = !1, t.autoPlay())
		/* WA-C0003-11 : 
		i(t.$slider).find('a, button').on({
			focus: function(e){
				if($(t.$slider).is('.initialized-tabindex')) return false;
				$(t.$slider).find('.slick-slide[aria-hidden="true"] a').attr('tabindex', -1);
				$(t.$slider).addClass('initialized-tabindex');
			}
		});
		*/
		/* WA-Common-Slick : */
		i(t.$slider).find('.slick-track').find('a, button').on({
			"focus.current": function(e){
				if(!$(this).closest('.slick-slide').hasClass('slick-active')) {
					$(this).closest('.slick-list').scrollLeft(0);
					var currentPage = parseInt($(this).closest('.slick-slide').attr('data-slick-index'));
					var oldPage = parseInt(i(t.$slider).find('.slick-active').eq(0).attr('data-slick-index'));

					//console.log(currentPage, oldPage);
					if(t.options.arrows) {
						if(currentPage == oldPage) {
							return false;
						} else if(currentPage > oldPage) {
							//console.log('next');
							t.$nextArrow.trigger('click');
						} else {
							//console.log('prev');
							t.$prevArrow.trigger('click');
						}
					} else {
						i(t.$slider).slick('slickGoTo', currentPage);
					}
					/*
					if(currentPage == oldPage) {
						return false;
					} else if(currentPage > oldPage) {
						t.changeSlide({
							data: {
								message: "next"
							}
						});
					} else {
						t.changeSlide({
							data: {
								message: "previous"
							}
						});
					}
					*/
				}
			}
		});
	}, e.prototype.initADA = function() {
		var e = this,
			t = Math.ceil(e.slideCount / e.options.slidesToShow),
			o = e.getNavigableIndexes().filter(function(i) {
				return i >= 0 && i < e.slideCount
			});
		// WA-Common-Slick
		/*
		e.$slides.add(e.$slideTrack.find(".slick-cloned")).attr({
			//"aria-hidden": "true"//, // WA-Common-Slick
			//tabindex: "-1"  // WA-Common-Slick
		}).find("a, input, button, select").attr({
			tabindex: "-1"
		}), */
		null !== e.$dots && (e.$slides.not(e.$slideTrack.find(".slick-cloned")).each(function(t) {
			var s = o.indexOf(t);
			i(this).attr({
				id: "slick-slide" + e.instanceUid + t, //, - WA-Common-Slick
				"tabindex": "-1" // WA-Common-Slick   	//test_200526
			}),i(this).find('a:not(.required-tabindex), button').attr({
				"tabindex": "-1" // WA-Common-Slick   	//test_200526
			}), -1 !== s && i(this).attr({
				//"aria-describedby": "slick-slide-control" + e.instanceUid + s
				"id": "slick-slide-control" + e.instanceUid + s,
			})
		}), e.$dots.attr("role", "tablist").find("li").each(function(s) {
			var n = o[s];
			var totalCnt = e.$dots.attr("role", "tablist").find("li").length;
			var dotsText = s + 1 +' of '+ totalCnt;
			if(e.$slider.data('wa-msg') != undefined){
				dotsText = e.$slider.data('wa-msg').replace('\#1', (s + 1) + ' of '+ totalCnt);
			}
			i(this).attr({
				role: "presentation"
			}), i(this).find("button").attr({	
				"tabindex" : "-1"
			}).text(dotsText), i(this).find("button").first().attr({
				//role: "tab", // remove - theJ
				//id: "slick-slide-control" + e.instanceUid + s,
				"aria-describedby": "slick-slide-control" + e.instanceUid + s,
				"role" : "tab",
				"aria-controls": "slick-slide-control" + e.instanceUid + s,
				//"aria-label": (s + 1 +' of '+ totalCnt),
				"aria-selected": null//,
				//tabindex: "-1"
			}).text(dotsText)
		//}).eq(e.currentSlide).find("button").attr({
		}).eq(e.currentSlide).find("a, button").attr({
			"aria-selected": "true",//, - WA-Common-Slick
			"tabindex": "0" // WA-Common-Slick
		}).end());
		if(!e.$slider.hasClass("notices-list")){
		for (var s = e.currentSlide, n = s + e.options.slidesToShow; s < n; s++) e.$slides.eq(s).attr("tabindex", 0);
		}
		e.activateADA()
	}, e.prototype.initArrowEvents = function() {
		var i = this;
		!0 === i.options.arrows && i.slideCount > i.options.slidesToShow && (i.$prevArrow.off("click.slick").on("click.slick", {
			message: "previous"
		}, i.changeSlide), i.$nextArrow.off("click.slick").on("click.slick", {
			message: "next"
		}, i.changeSlide), !0 === i.options.accessibility && (i.$prevArrow.on("keydown.slick", i.keyHandler), i.$nextArrow.on("keydown.slick", i.keyHandler)))
	}, e.prototype.initDotEvents = function() {
		var e = this;
		!0 === e.options.dots && (i("li", e.$dots).on("click.slick", {
			message: "index"
		}, e.changeSlide), !0 === e.options.accessibility && e.$dots.on("keydown.slick", e.keyHandler)), !0 === e.options.dots && !0 === e.options.pauseOnDotsHover && i("li", e.$dots).on("mouseenter.slick", i.proxy(e.interrupt, e, !0)).on("mouseleave.slick", i.proxy(e.interrupt, e, !1))
	}, e.prototype.initSlideEvents = function() {
		var e = this;
		e.options.pauseOnHover && (e.$list.on("mouseenter.slick", i.proxy(e.interrupt, e, !0)), e.$list.on("mouseleave.slick", i.proxy(e.interrupt, e, !1)))
	}, e.prototype.initializeEvents = function() {
		var e = this;
		e.initArrowEvents(), e.initDotEvents(), e.initSlideEvents(), e.$list.on("touchstart.slick mousedown.slick", {
			action: "start"
		}, e.swipeHandler), e.$list.on("touchmove.slick mousemove.slick", {
			action: "move"
		}, e.swipeHandler), e.$list.on("touchend.slick mouseup.slick", {
			action: "end"
		}, e.swipeHandler), e.$list.on("touchcancel.slick mouseleave.slick", {
			action: "end"
		}, e.swipeHandler), e.$list.on("click.slick", e.clickHandler), i(document).on(e.visibilityChange, i.proxy(e.visibility, e)), !0 === e.options.accessibility && e.$list.on("keydown.slick", e.keyHandler), !0 === e.options.focusOnSelect && i(e.$slideTrack).children().on("click.slick", e.selectHandler), i(window).on("orientationchange.slick.slick-" + e.instanceUid, i.proxy(e.orientationChange, e)), i(window).on("resize.slick.slick-" + e.instanceUid, i.proxy(e.resize, e)), i("[draggable!=true]", e.$slideTrack).on("dragstart", e.preventDefault), i(window).on("load.slick.slick-" + e.instanceUid, e.setPosition), i(e.setPosition)
	}, e.prototype.initUI = function() {
		var i = this;
		!0 === i.options.arrows && i.slideCount > i.options.slidesToShow && (i.$prevArrow.show(), i.$nextArrow.show()), !0 === i.options.dots && i.slideCount > i.options.slidesToShow && i.$dots.show()
	}, e.prototype.keyHandler = function(i) {
		var e = this;			
		var $radioTab = $('.model-group, .color-list, .size-list');
		$radioTab.each(function () {
			$(this).find('a').on('keydown', function(e){
				var keycode = e.keyCode
				var keys = {
					left: 37,
					right: 39,
				};
				var direction = {
					37: -1,
					39: 1,
				};
				var keyProceed = false;
				var index = $(e.target).parents('[role="radiogroup"]').find('[role="radio"]').index(this);
				if(keycode === keys.right){
					e.stopPropagation();
					keyProceed = true;
				} else if( keycode === keys.left){
					e.stopPropagation();
					keyProceed = true;
				}
				if (keyProceed) {
					targetTab(e);
				}
				function targetTab(e){
					e.preventDefault();
					var keyProceed = e.keyCode;
					var target = e.target;
					var targetTab = $(target).parents('[role="radiogroup"]').find('[role="radio"]').length;
						var targetActive = $(target).parents('[role="radiogroup"]').find('[role="radio"]');
						if($(target).parents('[role="radiogroup"]').length !== 0){
							if (direction[keyProceed]) {
								if(targetActive[index + direction[keyProceed]]){
									targetActive[index + direction[keyProceed]].focus();
								} else if (keyProceed === keys.left) {
									targetActive[0].focus();
								} else if (keyProceed === keys.right) {
									targetActive[targetTab - 1].focus();
								};
							}
						} else{
							console.log("not Accessibility Guide")
							//접근성 키보드 관련해서 wai 구조상 값이 잘못되면 나타남 해당 console시 radiogroup 유형을 확인하세요
						}
					}
				});
			});

		i.target.tagName.match("TEXTAREA|INPUT|SELECT") || (37 === i.keyCode && !0 === e.options.accessibility ? e.changeSlide({
			data: {
				message: !0 === e.options.rtl ? "next" : "previous"
			}
		}) : 39 === i.keyCode && !0 === e.options.accessibility && e.changeSlide({
			data: {
				message: !0 === e.options.rtl ? "previous" : "next"
			}
		}))
	}, e.prototype.lazyLoad = function() {
		function e(e) {
			i("img[data-lazy]", e).each(function() {
				var e = i(this),
					t = i(this).attr("data-lazy"),
					o = i(this).attr("data-srcset"),
					s = i(this).attr("data-sizes") || n.$slider.attr("data-sizes"),
					r = document.createElement("img");
				r.onload = function() {
					e.animate({
						opacity: 0
					}, 100, function() {
						o && (e.attr("srcset", o), s && e.attr("sizes", s)), e.attr("src", t).animate({
							opacity: 1
						}, 200, function() {
							e.removeAttr("data-lazy data-srcset data-sizes").removeClass("slick-loading")
						}), n.$slider.trigger("lazyLoaded", [n, e, t])
					})
				}, r.onerror = function() {
					//e.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"), n.$slider.trigger("lazyLoadError", [n, e, t])
					e.attr("data-src", e.attr("data-lazy")).removeAttr("data-lazy").addClass("lazyload").removeClass("slick-loading").addClass("slick-lazyload-error"), n.$slider.trigger("lazyLoadError", [n, e, t])
				}, r.src = t
			})
		}
		var t, o, s, n = this;
		if (!0 === n.options.centerMode ? !0 === n.options.infinite ? s = (o = n.currentSlide + (n.options.slidesToShow / 2 + 1)) + n.options.slidesToShow + 2 : (o = Math.max(0, n.currentSlide - (n.options.slidesToShow / 2 + 1)), s = n.options.slidesToShow / 2 + 1 + 2 + n.currentSlide) : (o = n.options.infinite ? n.options.slidesToShow + n.currentSlide : n.currentSlide, s = Math.ceil(o + n.options.slidesToShow), !0 === n.options.fade && (o > 0 && o--, s <= n.slideCount && s++)), t = n.$slider.find(".slick-slide").slice(o, s), "anticipated" === n.options.lazyLoad)
			for (var r = o - 1, l = s, d = n.$slider.find(".slick-slide"), a = 0; a < n.options.slidesToScroll; a++) r < 0 && (r = n.slideCount - 1), t = (t = t.add(d.eq(r))).add(d.eq(l)), r--, l++;
		e(t), n.slideCount <= n.options.slidesToShow ? e(n.$slider.find(".slick-slide")) : n.currentSlide >= n.slideCount - n.options.slidesToShow ? e(n.$slider.find(".slick-cloned").slice(0, n.options.slidesToShow)) : 0 === n.currentSlide && e(n.$slider.find(".slick-cloned").slice(-1 * n.options.slidesToShow))
	}, e.prototype.loadSlider = function() {
		var i = this;
		i.setPosition(), i.$slideTrack.css({
			opacity: 1
		}), i.$slider.removeClass("slick-loading"), i.initUI(), "progressive" === i.options.lazyLoad && i.progressiveLazyLoad()
	}, e.prototype.next = e.prototype.slickNext = function() {
		this.changeSlide({
			data: {
				message: "next"
			}
		})
	}, e.prototype.orientationChange = function() {
		var i = this;
		i.checkResponsive(), i.setPosition()
	}, e.prototype.pause = e.prototype.slickPause = function() {
		var i = this;
		i.autoPlayClear(), i.paused = !0
	}, e.prototype.play = e.prototype.slickPlay = function() {
		var i = this;
		i.autoPlay(), i.options.autoplay = !0, i.paused = !1, i.focussed = !1, i.interrupted = !1
	}, e.prototype.postSlide = function(e) {
		var t = this;
		t.unslicked || (t.$slider.trigger("afterChange", [t, e]), t.animating = !1, t.slideCount > t.options.slidesToShow && t.setPosition(), t.swipeLeft = null, t.options.autoplay && t.autoPlay(), !0 === t.options.accessibility && (t.initADA(), t.options.focusOnChange && i(t.$slides.get(t.currentSlide))/*.attr("tabindex", 0)*/.focus())) /* WA-Common-Slick */
	}, e.prototype.prev = e.prototype.slickPrev = function() {
		this.changeSlide({
			data: {
				message: "previous"
			}
		})
	}, e.prototype.preventDefault = function(i) {
		i.preventDefault()
	}, e.prototype.progressiveLazyLoad = function(e) {
		e = e || 1;
		var t, o, s, n, r, l = this,
			d = i("img[data-lazy]", l.$slider);
		d.length ? (t = d.first(), o = t.attr("data-lazy"), s = t.attr("data-srcset"), n = t.attr("data-sizes") || l.$slider.attr("data-sizes"), (r = document.createElement("img")).onload = function() {
			s && (t.attr("srcset", s), n && t.attr("sizes", n)), t.attr("src", o).removeAttr("data-lazy data-srcset data-sizes").removeClass("slick-loading"), !0 === l.options.adaptiveHeight && l.setPosition(), l.$slider.trigger("lazyLoaded", [l, t, o]), l.progressiveLazyLoad()
		}, r.onerror = function() {
			e < 3 ? setTimeout(function() {
				l.progressiveLazyLoad(e + 1)
			// }, 500) : (t.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"), l.$slider.trigger("lazyLoadError", [l, t, o]), l.progressiveLazyLoad())
			}, 500) : (t.attr("data-src", t.attr("data-lazy")).addClass("lazyload").removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"), l.$slider.trigger("lazyLoadError", [l, t, o]), l.progressiveLazyLoad())
		}, r.src = o) : l.$slider.trigger("allImagesLoaded", [l])
	}, e.prototype.refresh = function(e) {
		var t, o, s = this;
		o = s.slideCount - s.options.slidesToShow, !s.options.infinite && s.currentSlide > o && (s.currentSlide = o), s.slideCount <= s.options.slidesToShow && (s.currentSlide = 0), t = s.currentSlide, s.destroy(!0), i.extend(s, s.initials, {
			currentSlide: t
		}), s.init(), e || s.changeSlide({
			data: {
				message: "index",
				index: t
			}
		}, !1)
	}, e.prototype.registerBreakpoints = function() {
		var e, t, o, s = this,
			n = s.options.responsive || null;
		if ("array" === i.type(n) && n.length) {
			s.respondTo = s.options.respondTo || "window";
			for (e in n)
				if (o = s.breakpoints.length - 1, n.hasOwnProperty(e)) {
					for (t = n[e].breakpoint; o >= 0;) s.breakpoints[o] && s.breakpoints[o] === t && s.breakpoints.splice(o, 1), o--;
					s.breakpoints.push(t), s.breakpointSettings[t] = n[e].settings
				} s.breakpoints.sort(function(i, e) {
				return s.options.mobileFirst ? i - e : e - i
			})
		}
	}, e.prototype.reinit = function() {
		var e = this;
		e.$slides = e.$slideTrack.children(e.options.slide).addClass("slick-slide"), e.slideCount = e.$slides.length, e.currentSlide >= e.slideCount && 0 !== e.currentSlide && (e.currentSlide = e.currentSlide - e.options.slidesToScroll), e.slideCount <= e.options.slidesToShow && (e.currentSlide = 0), e.registerBreakpoints(), e.setProps(), e.setupInfinite(), e.buildArrows(), e.updateArrows(), e.initArrowEvents(), e.buildDots(), e.updateDots(), e.initDotEvents(), e.cleanUpSlideEvents(), e.initSlideEvents(), e.checkResponsive(!1, !0), !0 === e.options.focusOnSelect && i(e.$slideTrack).children().on("click.slick", e.selectHandler), e.setSlideClasses("number" == typeof e.currentSlide ? e.currentSlide : 0), e.setPosition(), e.focusHandler(), e.paused = !e.options.autoplay, e.autoPlay(), e.$slider.trigger("reInit", [e])
	}, e.prototype.resize = function() {
		var e = this;
		i(window).width() !== e.windowWidth && (clearTimeout(e.windowDelay), e.windowDelay = window.setTimeout(function() {
			e.windowWidth = i(window).width(), e.checkResponsive(), e.unslicked || e.setPosition()
		}, 50))
	}, e.prototype.removeSlide = e.prototype.slickRemove = function(i, e, t) {
		var o = this;
		if (i = "boolean" == typeof i ? !0 === (e = i) ? 0 : o.slideCount - 1 : !0 === e ? --i : i, o.slideCount < 1 || i < 0 || i > o.slideCount - 1) return !1;
		o.unload(), !0 === t ? o.$slideTrack.children().remove() : o.$slideTrack.children(this.options.slide).eq(i).remove(), o.$slides = o.$slideTrack.children(this.options.slide), o.$slideTrack.children(this.options.slide).detach(), o.$slideTrack.append(o.$slides), o.$slidesCache = o.$slides, o.reinit()
	}, e.prototype.setCSS = function(i) {
		var e, t, o = this,
			s = {};
		!0 === o.options.rtl && (i = -i), e = "left" == o.positionProp ? Math.ceil(i) + "px" : "0px", t = "top" == o.positionProp ? Math.ceil(i) + "px" : "0px", s[o.positionProp] = i, !1 === o.transformsEnabled ? o.$slideTrack.css(s) : (s = {}, !1 === o.cssTransitions ? (s[o.animType] = "translate(" + e + ", " + t + ")", o.$slideTrack.css(s)) : (s[o.animType] = "translate3d(" + e + ", " + t + ", 0px)", o.$slideTrack.css(s)))
	}, e.prototype.setDimensions = function() {
		var i = this;
		!1 === i.options.vertical ? !0 === i.options.centerMode && i.$list.css({
			padding: "0px " + i.options.centerPadding
		}) : (i.$list.height(i.$slides.first().outerHeight(!0) * i.options.slidesToShow), !0 === i.options.centerMode && i.$list.css({
			padding: i.options.centerPadding + " 0px"
		})), i.listWidth = i.$list.width(), i.listHeight = i.$list.height(), !1 === i.options.vertical && !1 === i.options.variableWidth ? (i.slideWidth = Math.ceil(i.listWidth / i.options.slidesToShow), i.$slideTrack.width(Math.ceil(i.slideWidth * i.$slideTrack.children(".slick-slide").length))) : !0 === i.options.variableWidth ? i.$slideTrack.width(5e3 * i.slideCount) : (i.slideWidth = Math.ceil(i.listWidth), i.$slideTrack.height(Math.ceil(i.$slides.first().outerHeight(!0) * i.$slideTrack.children(".slick-slide").length)));
		var e = i.$slides.first().outerWidth(!0) - i.$slides.first().width();
		!1 === i.options.variableWidth && i.$slideTrack.children(".slick-slide").width(i.slideWidth - e)
	}, e.prototype.setFade = function() {
		var e, t = this;
		t.$slides.each(function(o, s) {
			e = t.slideWidth * o * -1, !0 === t.options.rtl ? i(s).css({
				position: "relative",
				right: e,
				top: 0,
				zIndex: t.options.zIndex - 2,
				opacity: 0
			}) : i(s).css({
				position: "relative",
				left: e,
				top: 0,
				zIndex: t.options.zIndex - 2,
				opacity: 0
			})
		}), t.$slides.eq(t.currentSlide).css({
			zIndex: t.options.zIndex - 1,
			opacity: 1
		})
	}, e.prototype.setHeight = function() {
		var i = this;
		if (1 === i.options.slidesToShow && !0 === i.options.adaptiveHeight && !1 === i.options.vertical) {
			var e = i.$slides.eq(i.currentSlide).outerHeight(!0);
			i.$list.css("height", e)
		}
	}, e.prototype.setOption = e.prototype.slickSetOption = function() {
		var e, t, o, s, n, r = this,
			l = !1;
		if ("object" === i.type(arguments[0]) ? (o = arguments[0], l = arguments[1], n = "multiple") : "string" === i.type(arguments[0]) && (o = arguments[0], s = arguments[1], l = arguments[2], "responsive" === arguments[0] && "array" === i.type(arguments[1]) ? n = "responsive" : void 0 !== arguments[1] && (n = "single")), "single" === n) r.options[o] = s;
		else if ("multiple" === n) i.each(o, function(i, e) {
			r.options[i] = e
		});
		else if ("responsive" === n)
			for (t in s)
				if ("array" !== i.type(r.options.responsive)) r.options.responsive = [s[t]];
				else {
					for (e = r.options.responsive.length - 1; e >= 0;) r.options.responsive[e].breakpoint === s[t].breakpoint && r.options.responsive.splice(e, 1), e--;
					r.options.responsive.push(s[t])
				} l && (r.unload(), r.reinit())
	}, e.prototype.setPosition = function() {
		var i = this;
		i.setDimensions(), i.setHeight(), !1 === i.options.fade ? i.setCSS(i.getLeft(i.currentSlide)) : i.setFade(), i.$slider.trigger("setPosition", [i])
	}, e.prototype.setProps = function() {
		var i = this,
			e = document.body.style;
		i.positionProp = !0 === i.options.vertical ? "top" : "left", "top" === i.positionProp ? i.$slider.addClass("slick-vertical") : i.$slider.removeClass("slick-vertical"), void 0 === e.WebkitTransition && void 0 === e.MozTransition && void 0 === e.msTransition || !0 === i.options.useCSS && (i.cssTransitions = !0), i.options.fade && ("number" == typeof i.options.zIndex ? i.options.zIndex < 3 && (i.options.zIndex = 3) : i.options.zIndex = i.defaults.zIndex), void 0 !== e.OTransform && (i.animType = "OTransform", i.transformType = "-o-transform", i.transitionType = "OTransition", void 0 === e.perspectiveProperty && void 0 === e.webkitPerspective && (i.animType = !1)), void 0 !== e.MozTransform && (i.animType = "MozTransform", i.transformType = "-moz-transform", i.transitionType = "MozTransition", void 0 === e.perspectiveProperty && void 0 === e.MozPerspective && (i.animType = !1)), void 0 !== e.webkitTransform && (i.animType = "webkitTransform", i.transformType = "-webkit-transform", i.transitionType = "webkitTransition", void 0 === e.perspectiveProperty && void 0 === e.webkitPerspective && (i.animType = !1)), void 0 !== e.msTransform && (i.animType = "msTransform", i.transformType = "-ms-transform", i.transitionType = "msTransition", void 0 === e.msTransform && (i.animType = !1)), void 0 !== e.transform && !1 !== i.animType && (i.animType = "transform", i.transformType = "transform", i.transitionType = "transition"), i.transformsEnabled = i.options.useTransform && null !== i.animType && !1 !== i.animType
	}, e.prototype.setSlideClasses = function(i) {
		var e, t, o, s, n = this;
		// .attr("aria-hidden", "true") >> WA-Common-Slick, 
		if (t = n.$slider.find(".slick-slide").removeClass("slick-active slick-center slick-current"),/* LGEUS-11794 : 20190813 modify */ (!n.options.defaultFocus?n.$slides.eq(i).addClass("slick-current"):null)/* //LGEUS-11794 : 20190813 modify */, !0 === n.options.centerMode) {
			var r = n.options.slidesToShow % 2 == 0 ? 1 : 0;
			e = Math.floor(n.options.slidesToShow / 2), !0 === n.options.infinite && (i >= e && i <= n.slideCount - 1 - e ? n.$slides.slice(i - e + r, i + e + 1).addClass("slick-active") : (o = n.options.slidesToShow + i, t.slice(o - e + 1 + r, o + e + 2).addClass("slick-active")), 0 === i ? t.eq(t.length - 1 - n.options.slidesToShow).addClass("slick-center") : i === n.slideCount - 1 && t.eq(n.options.slidesToShow).addClass("slick-center")), n.$slides.eq(i).addClass("slick-center")
		} else i >= 0 && i <= n.slideCount - n.options.slidesToShow ? n.$slides.slice(i, i + n.options.slidesToShow).addClass("slick-active") : t.length <= n.options.slidesToShow ? t.addClass("slick-active") : (s = n.slideCount % n.options.slidesToShow, o = !0 === n.options.infinite ? n.options.slidesToShow + i : i, n.options.slidesToShow == n.options.slidesToScroll && n.slideCount - i < n.options.slidesToShow ? t.slice(o - (n.options.slidesToShow - s), o + s).addClass("slick-active") : t.slice(o, o + n.options.slidesToShow).addClass("slick-active"));
		"ondemand" !== n.options.lazyLoad && "anticipated" !== n.options.lazyLoad || n.lazyLoad()
	}, e.prototype.setupInfinite = function() {
		var e, t, o, s = this;
		if (!0 === s.options.fade && (s.options.centerMode = !1), !0 === s.options.infinite && !1 === s.options.fade && (t = null, s.slideCount > s.options.slidesToShow)) {
			for (o = !0 === s.options.centerMode ? s.options.slidesToShow + 1 : s.options.slidesToShow, e = s.slideCount; e > s.slideCount - o; e -= 1) t = e - 1, i(s.$slides[t]).clone(!0).attr("id", "").attr("data-slick-index", t - s.slideCount).prependTo(s.$slideTrack).addClass("slick-cloned");
			for (e = 0; e < o + s.slideCount; e += 1) t = e, i(s.$slides[t]).clone(!0).attr("id", "").attr("data-slick-index", t + s.slideCount).appendTo(s.$slideTrack).addClass("slick-cloned");
			s.$slideTrack.find(".slick-cloned").find("[id]").each(function() {
				i(this).attr("id", "")
			})
		}
	}, e.prototype.interrupt = function(i) {
		var e = this;
		i || e.autoPlay(), e.interrupted = i
	}, e.prototype.selectHandler = function(e) {
		var t = this,
			o = i(e.target).is(".slick-slide") ? i(e.target) : i(e.target).parents(".slick-slide"),
			s = parseInt(o.attr("data-slick-index"));
		s || (s = 0), t.slideCount <= t.options.slidesToShow ? t.slideHandler(s, !1, !0) : t.slideHandler(s)
	}, e.prototype.slideHandler = function(i, e, t) {
		var o, s, n, r, l, d = null,
			a = this;
		if (e = e || !1, !(!0 === a.animating && !0 === a.options.waitForAnimate || !0 === a.options.fade && a.currentSlide === i))
			if (!1 === e && a.asNavFor(i), o = i, d = a.getLeft(o), r = a.getLeft(a.currentSlide), a.currentLeft = null === a.swipeLeft ? r : a.swipeLeft, !1 === a.options.infinite && !1 === a.options.centerMode && (i < 0 || i > a.getDotCount() * a.options.slidesToScroll)) !1 === a.options.fade && (o = a.currentSlide, !0 !== t ? a.animateSlide(r, function() {
				a.postSlide(o)
			}) : a.postSlide(o));
			else if (!1 === a.options.infinite && !0 === a.options.centerMode && (i < 0 || i > a.slideCount - a.options.slidesToScroll)) !1 === a.options.fade && (o = a.currentSlide, !0 !== t ? a.animateSlide(r, function() {
			a.postSlide(o)
		}) : a.postSlide(o));
		else {
			if (a.options.autoplay && clearInterval(a.autoPlayTimer), s = o < 0 ? a.slideCount % a.options.slidesToScroll != 0 ? a.slideCount - a.slideCount % a.options.slidesToScroll : a.slideCount + o : o >= a.slideCount ? a.slideCount % a.options.slidesToScroll != 0 ? 0 : o - a.slideCount : o, a.animating = !0, a.$slider.trigger("beforeChange", [a, a.currentSlide, s]), n = a.currentSlide, a.currentSlide = s, a.setSlideClasses(a.currentSlide), a.options.asNavFor && (l = (l = a.getNavTarget()).slick("getSlick")).slideCount <= l.options.slidesToShow && l.setSlideClasses(a.currentSlide), a.updateDots(), a.updateArrows(), !0 === a.options.fade) return !0 !== t ? (a.fadeSlideOut(n), a.fadeSlide(s, function() {
				a.postSlide(s)
			})) : a.postSlide(s), void a.animateHeight();
			!0 !== t ? a.animateSlide(d, function() {
				a.postSlide(s)
			}) : a.postSlide(s)
		}
	}, e.prototype.startLoad = function() {
		var i = this;
		!0 === i.options.arrows && i.slideCount > i.options.slidesToShow && (i.$prevArrow.hide(), i.$nextArrow.hide()), !0 === i.options.dots && i.slideCount > i.options.slidesToShow && i.$dots.hide(), i.$slider.addClass("slick-loading")
	}, e.prototype.swipeDirection = function() {
		var i, e, t, o, s = this;
		return i = s.touchObject.startX - s.touchObject.curX, e = s.touchObject.startY - s.touchObject.curY, t = Math.atan2(e, i), (o = Math.round(180 * t / Math.PI)) < 0 && (o = 360 - Math.abs(o)), o <= 45 && o >= 0 ? !1 === s.options.rtl ? "left" : "right" : o <= 360 && o >= 315 ? !1 === s.options.rtl ? "left" : "right" : o >= 135 && o <= 225 ? !1 === s.options.rtl ? "right" : "left" : !0 === s.options.verticalSwiping ? o >= 35 && o <= 135 ? "down" : "up" : "vertical"
	}, e.prototype.swipeEnd = function(i) {
		var e, t, o = this;
		if (o.dragging = !1, o.swiping = !1, o.scrolling) return o.scrolling = !1, !1;
		if (o.interrupted = !1, o.shouldClick = !(o.touchObject.swipeLength > 10), void 0 === o.touchObject.curX) return !1;
		if (!0 === o.touchObject.edgeHit && o.$slider.trigger("edge", [o, o.swipeDirection()]), o.touchObject.swipeLength >= o.touchObject.minSwipe) {
			switch (t = o.swipeDirection()) {
				case "left":
				case "down":
					e = o.options.swipeToSlide ? o.checkNavigable(o.currentSlide + o.getSlideCount()) : o.currentSlide + o.getSlideCount(), o.currentDirection = 0;
					break;
				case "right":
				case "up":
					e = o.options.swipeToSlide ? o.checkNavigable(o.currentSlide - o.getSlideCount()) : o.currentSlide - o.getSlideCount(), o.currentDirection = 1
			}
			"vertical" != t && (o.slideHandler(e), o.touchObject = {}, o.$slider.trigger("swipe", [o, t]))
		} else o.touchObject.startX !== o.touchObject.curX && (o.slideHandler(o.currentSlide), o.touchObject = {})
	}, e.prototype.swipeHandler = function(i) {
		var e = this;
		if (!(!1 === e.options.swipe || "ontouchend" in document && !1 === e.options.swipe || !1 === e.options.draggable && -1 !== i.type.indexOf("mouse"))) switch (e.touchObject.fingerCount = i.originalEvent && void 0 !== i.originalEvent.touches ? i.originalEvent.touches.length : 1, e.touchObject.minSwipe = e.listWidth / e.options.touchThreshold, !0 === e.options.verticalSwiping && (e.touchObject.minSwipe = e.listHeight / e.options.touchThreshold), i.data.action) {
			case "start":
				e.swipeStart(i);
				break;
			case "move":
				e.swipeMove(i);
				break;
			case "end":
				e.swipeEnd(i)
		}
	}, e.prototype.swipeMove = function(i) {
		var e, t, o, s, n, r, l = this;
		return n = void 0 !== i.originalEvent ? i.originalEvent.touches : null, !(!l.dragging || l.scrolling || n && 1 !== n.length) && (e = l.getLeft(l.currentSlide), l.touchObject.curX = void 0 !== n ? n[0].pageX : i.clientX, l.touchObject.curY = void 0 !== n ? n[0].pageY : i.clientY, l.touchObject.swipeLength = Math.round(Math.sqrt(Math.pow(l.touchObject.curX - l.touchObject.startX, 2))), r = Math.round(Math.sqrt(Math.pow(l.touchObject.curY - l.touchObject.startY, 2))), !l.options.verticalSwiping && !l.swiping && r > 4 ? (l.scrolling = !0, !1) : (!0 === l.options.verticalSwiping && (l.touchObject.swipeLength = r), t = l.swipeDirection(), void 0 !== i.originalEvent && l.touchObject.swipeLength > 4 && (l.swiping = !0, i.preventDefault()), s = (!1 === l.options.rtl ? 1 : -1) * (l.touchObject.curX > l.touchObject.startX ? 1 : -1), !0 === l.options.verticalSwiping && (s = l.touchObject.curY > l.touchObject.startY ? 1 : -1), o = l.touchObject.swipeLength, l.touchObject.edgeHit = !1, !1 === l.options.infinite && (0 === l.currentSlide && "right" === t || l.currentSlide >= l.getDotCount() && "left" === t) && (o = l.touchObject.swipeLength * l.options.edgeFriction, l.touchObject.edgeHit = !0), !1 === l.options.vertical ? l.swipeLeft = e + o * s : l.swipeLeft = e + o * (l.$list.height() / l.listWidth) * s, !0 === l.options.verticalSwiping && (l.swipeLeft = e + o * s), !0 !== l.options.fade && !1 !== l.options.touchMove && (!0 === l.animating ? (l.swipeLeft = null, !1) : void l.setCSS(l.swipeLeft))))
	}, e.prototype.swipeStart = function(i) {
		var e, t = this;
		if (t.interrupted = !0, 1 !== t.touchObject.fingerCount || t.slideCount <= t.options.slidesToShow) return t.touchObject = {}, !1;
		void 0 !== i.originalEvent && void 0 !== i.originalEvent.touches && (e = i.originalEvent.touches[0]), t.touchObject.startX = t.touchObject.curX = void 0 !== e ? e.pageX : i.clientX, t.touchObject.startY = t.touchObject.curY = void 0 !== e ? e.pageY : i.clientY, t.dragging = !0
	}, e.prototype.unfilterSlides = e.prototype.slickUnfilter = function() {
		var i = this;
		null !== i.$slidesCache && (i.unload(), i.$slideTrack.children(this.options.slide).detach(), i.$slidesCache.appendTo(i.$slideTrack), i.reinit())
	}, e.prototype.unload = function() {
		var e = this;
		i(".slick-cloned", e.$slider).remove(), e.$dots && e.$dots.remove(), e.$prevArrow && e.htmlExpr.test(e.options.prevArrow) && e.$prevArrow.remove(), e.$nextArrow && e.htmlExpr.test(e.options.nextArrow) && e.$nextArrow.remove(), e.$slides.removeClass("slick-slide slick-active slick-visible slick-current").css("width", "") // attr("aria-hidden", "true") WA-Common-slick
	}, e.prototype.unslick = function(i) {
		var e = this;
		e.$slider.trigger("unslick", [e, i]), e.destroy()
	}, e.prototype.updateArrows = function() {
		var i = this;
		Math.floor(i.options.slidesToShow / 2), !0 === i.options.arrows && i.slideCount > i.options.slidesToShow && !i.options.infinite && (i.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false").removeAttr("disabled"), i.$nextArrow.removeClass("slick-disabled").attr("aria-disabled", "false").removeAttr("disabled"), 0 === i.currentSlide ? (i.$prevArrow.addClass("slick-disabled").attr("aria-disabled", "true").attr("disabled", "true"), i.$nextArrow.removeClass("slick-disabled").attr("aria-disabled", "false").removeAttr("disabled")) : i.currentSlide >= i.slideCount - i.options.slidesToShow && !1 === i.options.centerMode ? (i.$nextArrow.addClass("slick-disabled").attr("aria-disabled", "true").attr("disabled", "true"), i.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false").removeAttr("disabled")) : i.currentSlide >= i.slideCount - 1 && !0 === i.options.centerMode && (i.$nextArrow.addClass("slick-disabled").attr("aria-disabled", "true").attr("disabled", "true"), i.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false").removeAttr("disabled"))) /* WA-Common-Slick */
	}, e.prototype.updateDots = function() {
		var i = this;
		null !== i.$dots && (
			i.$dots.find("li").removeClass("slick-active").end(), 
			i.$dots.find("li").eq(Math.floor(i.currentSlide / i.options.slidesToScroll)).addClass("slick-active"))
	}, e.prototype.visibility = function() {
		var i = this;
		i.options.autoplay && (document[i.hidden] ? i.interrupted = !0 : i.interrupted = !1)
	}, i.fn.slick = function() {
		var i, t, o = this,
			s = arguments[0],
			n = Array.prototype.slice.call(arguments, 1),
			r = o.length;
		for (i = 0; i < r; i++)
			if ("object" == typeof s || void 0 === s ? o[i].slick = new e(o[i], s) : t = o[i].slick[s].apply(o[i].slick, n), void 0 !== t) return t;
		return o
	}
});
/* //LGECI-261 edit */

// InlineSVG 2.0.0
	!function(e){"use strict";e.fn.inlineSVG=function(t){t=e.extend({eachAfter:null,allAfter:null,beforeReplace:null,replacedClass:"replaced-svg",keepSize:!0,keepStyle:!0},t||{});var l=this,a=0;return l.each(function(){var r=e(this),n=r.attr("id"),c=r.attr("class"),i=r.attr("src");e.get(i,function(i){function s(n){n="boolean"===e.type(n)?n:!0,n?(r.replaceWith(f),t.eachAfter&&t.eachAfter.call(f.get(0))):f.remove(),++a===l.length&&t.allAfter&&t.allAfter.call(null)}var f=e(i).find("svg"),h=[];if(n&&f.attr("id",n),c&&h.push(c),t.replacedClass&&h.push(t.replacedClass),f.attr("class",h.join(" ")),f.removeAttr("xmlns:a"),t.keepSize){var p=r.attr("width"),u=r.attr("height");p&&f.attr("width",p),u&&f.attr("height",u)}if(t.keepStyle){var o=r.attr("style");o&&f.attr("style",o)}t.beforeReplace?t.beforeReplace.call(null,r,f,s):s()},"xml")})}}(jQuery);

// jQuery Cookie Plugin v1.4.1
 !function(e){"function"==typeof define&&define.amd?define(["jquery"],e):"object"==typeof exports?e(require("jquery")):e(jQuery)}(function(e){var o=/\+/g;function n(e){return r.raw?e:encodeURIComponent(e)}function i(n,i){var t=r.raw?n:function(e){0===e.indexOf('"')&&(e=e.slice(1,-1).replace(/\\"/g,'"').replace(/\\\\/g,"\\"));try{return e=decodeURIComponent(e.replace(o," ")),r.json?JSON.parse(e):e}catch(e){}}(n);return e.isFunction(i)?i(t):t}var r=e.cookie=function(o,t,c){if(void 0!==t&&!e.isFunction(t)){if("number"==typeof(c=e.extend({},r.defaults,c)).expires){var u=c.expires,a=c.expires=new Date;a.setTime(+a+864e5*u)}return document.cookie=[n(o),"=",(d=t,n(r.json?JSON.stringify(d):String(d))),c.expires?"; expires="+c.expires.toUTCString():"",c.path?"; path="+c.path:"",c.domain?"; domain="+c.domain:"",c.secure?"; secure":""].join("")}for(var d,f,p=o?void 0:{},s=document.cookie?document.cookie.split("; "):[],m=0,v=s.length;m<v;m++){var x=s[m].split("="),k=(f=x.shift(),r.raw?f:decodeURIComponent(f)),l=x.join("=");if(o&&o===k){p=i(l,t);break}o||void 0===(l=i(l))||(p[k]=l)}return p};r.defaults={},e.removeCookie=function(o,n){return void 0!==e.cookie(o)&&(e.cookie(o,"",e.extend({},n,{expires:-1})),!e.cookie(o))}});
$.cookie.raw = true;

// jQuery Mousewheel 3.1.13
	(function (factory) {
		if ( typeof define === 'function' && define.amd ) {
			// AMD. Register as an anonymous module.
			define(['jquery'], factory);
		} else if (typeof exports === 'object') {
			// Node/CommonJS style for Browserify
			module.exports = factory;
		} else {
			// Browser globals
			factory(jQuery);
		}
	}(function ($) {

		var toFix  = ['wheel', 'mousewheel', 'DOMMouseScroll', 'MozMousePixelScroll'],
			toBind = ( 'onwheel' in document || document.documentMode >= 9 ) ?
						['wheel'] : ['mousewheel', 'DomMouseScroll', 'MozMousePixelScroll'],
			slice  = Array.prototype.slice,
			nullLowestDeltaTimeout, lowestDelta;

		if ( $.event.fixHooks ) {
			for ( var i = toFix.length; i; ) {
				$.event.fixHooks[ toFix[--i] ] = $.event.mouseHooks;
			}
		}

		var special = $.event.special.mousewheel = {
			version: '3.1.12',

			setup: function() {
				if ( this.addEventListener ) {
					for ( var i = toBind.length; i; ) {
						this.addEventListener( toBind[--i], handler, false );
					}
				} else {
					this.onmousewheel = handler;
				}
				// Store the line height and page height for this particular element
				$.data(this, 'mousewheel-line-height', special.getLineHeight(this));
				$.data(this, 'mousewheel-page-height', special.getPageHeight(this));
			},

			teardown: function() {
				if ( this.removeEventListener ) {
					for ( var i = toBind.length; i; ) {
						this.removeEventListener( toBind[--i], handler, false );
					}
				} else {
					this.onmousewheel = null;
				}
				// Clean up the data we added to the element
				$.removeData(this, 'mousewheel-line-height');
				$.removeData(this, 'mousewheel-page-height');
			},

			getLineHeight: function(elem) {
				var $elem = $(elem),
					$parent = $elem['offsetParent' in $.fn ? 'offsetParent' : 'parent']();
				if (!$parent.length) {
					$parent = $('body');
				}
				return parseInt($parent.css('fontSize'), 10) || parseInt($elem.css('fontSize'), 10) || 16;
			},

			getPageHeight: function(elem) {
				return $(elem).height();
			},

			settings: {
				adjustOldDeltas: true, // see shouldAdjustOldDeltas() below
				normalizeOffset: true  // calls getBoundingClientRect for each event
			}
		};

		$.fn.extend({
			mousewheel: function(fn) {
				return fn ? this.bind('mousewheel', fn) : this.trigger('mousewheel');
			},

			unmousewheel: function(fn) {
				return this.unbind('mousewheel', fn);
			}
		});


		function handler(event) {
			var orgEvent   = event || window.event,
				args       = slice.call(arguments, 1),
				delta      = 0,
				deltaX     = 0,
				deltaY     = 0,
				absDelta   = 0,
				offsetX    = 0,
				offsetY    = 0;
			event = $.event.fix(orgEvent);
			event.type = 'mousewheel';

			// Old school scrollwheel delta
			if ( 'detail'      in orgEvent ) { deltaY = orgEvent.detail * -1;      }
			if ( 'wheelDelta'  in orgEvent ) { deltaY = orgEvent.wheelDelta;       }
			if ( 'wheelDeltaY' in orgEvent ) { deltaY = orgEvent.wheelDeltaY;      }
			if ( 'wheelDeltaX' in orgEvent ) { deltaX = orgEvent.wheelDeltaX * -1; }

			// Firefox < 17 horizontal scrolling related to DOMMouseScroll event
			if ( 'axis' in orgEvent && orgEvent.axis === orgEvent.HORIZONTAL_AXIS ) {
				deltaX = deltaY * -1;
				deltaY = 0;
			}

			// Set delta to be deltaY or deltaX if deltaY is 0 for backwards compatabilitiy
			delta = deltaY === 0 ? deltaX : deltaY;

			// New school wheel delta (wheel event)
			if ( 'deltaY' in orgEvent ) {
				deltaY = orgEvent.deltaY * -1;
				delta  = deltaY;
			}
			if ( 'deltaX' in orgEvent ) {
				deltaX = orgEvent.deltaX;
				if ( deltaY === 0 ) { delta  = deltaX * -1; }
			}

			// No change actually happened, no reason to go any further
			if ( deltaY === 0 && deltaX === 0 ) { return; }

			// Need to convert lines and pages to pixels if we aren't already in pixels
			// There are three delta modes:
			//   * deltaMode 0 is by pixels, nothing to do
			//   * deltaMode 1 is by lines
			//   * deltaMode 2 is by pages
			if ( orgEvent.deltaMode === 1 ) {
				var lineHeight = $.data(this, 'mousewheel-line-height');
				delta  *= lineHeight;
				deltaY *= lineHeight;
				deltaX *= lineHeight;
			} else if ( orgEvent.deltaMode === 2 ) {
				var pageHeight = $.data(this, 'mousewheel-page-height');
				delta  *= pageHeight;
				deltaY *= pageHeight;
				deltaX *= pageHeight;
			}

			// Store lowest absolute delta to normalize the delta values
			absDelta = Math.max( Math.abs(deltaY), Math.abs(deltaX) );

			if ( !lowestDelta || absDelta < lowestDelta ) {
				lowestDelta = absDelta;

				// Adjust older deltas if necessary
				if ( shouldAdjustOldDeltas(orgEvent, absDelta) ) {
					lowestDelta /= 40;
				}
			}

			// Adjust older deltas if necessary
			if ( shouldAdjustOldDeltas(orgEvent, absDelta) ) {
				// Divide all the things by 40!
				delta  /= 40;
				deltaX /= 40;
				deltaY /= 40;
			}

			// Get a whole, normalized value for the deltas
			delta  = Math[ delta  >= 1 ? 'floor' : 'ceil' ](delta  / lowestDelta);
			deltaX = Math[ deltaX >= 1 ? 'floor' : 'ceil' ](deltaX / lowestDelta);
			deltaY = Math[ deltaY >= 1 ? 'floor' : 'ceil' ](deltaY / lowestDelta);

			// Normalise offsetX and offsetY properties
			if ( special.settings.normalizeOffset && this.getBoundingClientRect ) {
				var boundingRect = this.getBoundingClientRect();
				offsetX = event.clientX - boundingRect.left;
				offsetY = event.clientY - boundingRect.top;
			}

			// Add information to the event object
			event.deltaX = deltaX;
			event.deltaY = deltaY;
			event.deltaFactor = lowestDelta;
			event.offsetX = offsetX;
			event.offsetY = offsetY;
			// Go ahead and set deltaMode to 0 since we converted to pixels
			// Although this is a little odd since we overwrite the deltaX/Y
			// properties with normalized deltas.
			event.deltaMode = 0;

			// Add event and delta to the front of the arguments
			args.unshift(event, delta, deltaX, deltaY);

			// Clearout lowestDelta after sometime to better
			// handle multiple device types that give different
			// a different lowestDelta
			// Ex: trackpad = 3 and mouse wheel = 120
			if (nullLowestDeltaTimeout) { clearTimeout(nullLowestDeltaTimeout); }
			nullLowestDeltaTimeout = setTimeout(nullLowestDelta, 200);

			return ($.event.dispatch || $.event.handle).apply(this, args);
		}

		function nullLowestDelta() {
			lowestDelta = null;
		}

		function shouldAdjustOldDeltas(orgEvent, absDelta) {
			// If this is an older event and the delta is divisable by 120,
			// then we are assuming that the browser is treating this as an
			// older mouse wheel event and that we should divide the deltas
			// by 40 to try and get a more usable deltaFactor.
			// Side note, this actually impacts the reported scroll distance
			// in older browsers and can cause scrolling to be slower than native.
			// Turn this off by setting $.event.special.mousewheel.settings.adjustOldDeltas to false.
			return special.settings.adjustOldDeltas && orgEvent.type === 'mousewheel' && absDelta % 120 === 0;
		}

	}));

// tiny Layer
var tinyLayer = (function () {
	var initModule = function ( $container ){
		if(document.querySelector($container)){

			$(document).on('mouseenter focus', $container, function(e) {
				// init
				e.preventDefault();
				var _this = $(this),
					tooltip_title = _this.text(),
					tooltip_x =  _this.offset().left,
					tooltip_y = _this.offset().top - 30,
					swatch_tooltip, swatch_tooltip_arrow, out_x;
					
					$('.tooltip-box').remove();
					//_this.siblings().attr('id','')
					$('#tooltipId').attr('id','');

				// create tooltip
				_this.attr('id','tooltipId')
				$('body').append('<span class="tooltip-box" aria-describedby="tooltipId"><span class="arrow"></span><span class="text">'+ tooltip_title +'</span></span>');
				
				swatch_tooltip = $('.tooltip-box');
				swatch_tooltip_arrow = swatch_tooltip.find('.arrow');
				
				swatch_tooltip
					.css('max-width', _this.closest('.model-group').width())
					.css('left', Math.floor(tooltip_x + (_this.innerWidth() / 2)) - (swatch_tooltip.innerWidth() / 2))
					.css('top', tooltip_y - swatch_tooltip.height());

				if(swatch_tooltip.offset().left < 0){
					out_x = parseInt(swatch_tooltip_arrow.css('margin-left').replace('px', '')) + swatch_tooltip.offset().left;
					swatch_tooltip.css('left', 0);
					swatch_tooltip_arrow.css('margin-left', out_x);
				};
				if(swatch_tooltip.offset().left + swatch_tooltip.innerWidth() + 2 == $(window).width()){
					out_x = 0 ;
					swatch_tooltip_arrow.css('margin-left', out_x);
				}
			}).on('focusout mouseleave', $container,function(e){
				e.preventDefault();
				$('.tooltip-box').remove();
			})
		};
	};

	return { initModule : initModule };
}());