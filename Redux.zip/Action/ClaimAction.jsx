// Dispatch Declaration
export default function viewList(){
    return {
        type: 'LIST',
        claims: []
    }
}
