import { combineReducers } from 'redux';
import claim from './ClaimReducer.jsx';

export default combineReducers({
  claim,
})