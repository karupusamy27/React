import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import { createStore } from 'redux';
import { Provider } from 'react-redux';

import View from './components/View.jsx';
import Submit from './components/Submit.jsx';
import Login from './components/app.jsx';
import reducer from './Reducer/ClaimReducer.jsx';
import viewList from './Action/ClaimAction.jsx';
import Home from './components/Home.jsx';
import Update from './components/update.jsx';

const pino = require('pino');
const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

//store
const store = createStore(reducer);

//subscribe
store.subscribe(() =>
    logger.info("Claim List Details(Redux):", store.getState())
);

//dispatch Action
store.dispatch(viewList());

ReactDOM.render(
    <Provider store={store}>
        <BrowserRouter >
            <div>
                <Switch>
                    <Route path='/login' component={Login} exact={true}></Route>
                    <Route path='/home' component={Home} exact={true}></Route>
                    <Route path='/view' component={View} exact={true}></Route>
                    <Route path="/submit" component={Submit} exact={true}></Route>
                    <Route path="/update" component={Update} exact={true}></Route>
                    <Route path="/submit/:id" component={Submit} exact={true}></Route>
                </Switch>
            </div>
        </BrowserRouter>
    </Provider>
    , document.getElementById('app'));