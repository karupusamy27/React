import React from 'react';
import axios from 'axios';

import { Alert } from 'react-bootstrap';
const pino = require('pino');
const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isInvalidUser: true,
      claim: [],
      username: null,
      password: null,
      errors: {
        username: '',
        password: '',
      }
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleUsername = this.handleUsername.bind(this);
    this.handlePassword = this.handlePassword.bind(this);
  }
  handleUsername(event) {
    this.setState({ username: event.target.value });
  }
  handlePassword(event) {
    this.setState({ password: event.target.value });
  }
  handleChange(event) {
    event.preventDefault();
    const { name, value } = event.target;
    let errors = this.state.errors;

    switch (name) {
      case 'username':
        errors.username =
          value.length < 5
            ? 'User Name must be at least 5 characters long!'
            : '';
        break;
      case 'password':
        errors.password =
          value.length < 5
            ? 'Password must be at least 5 characters long!'
            : '';
        break;
      default:
        break;
    }

    this.setState({ errors, [name]: value });
  }

  handleSubmit(event) {
    event.preventDefault();
    let foundUser = false;
    this.state.claim.map(claim => {
      if ((this.state.username == claim.username) && ((this.state.password == claim.password))) {
        foundUser = true;
      }
    })
      if (foundUser) {
        logger.info('Welcome Home Pgae!!!');
        logger.info(`Logged in user: ${this.state.username}!!!`);
        this.props.history.push('/home');
      } else {
        logger.info('Invalid Login Credentials!!!');
        this.setState({ invalidUser: true });
      }
    
  }
  componentDidMount() {
    axios.get(`http://localhost:7005/users`)
      .then(res => {
        this.setState({
          claim: res.data,
        });
      })
  }

  render() {
    const { errors } = this.state;
    return (
      <div>
        <header>
          <h1>Claim Management System</h1>
        </header>
        <div className='wrapper'>
          <div className='form-wrapper'>
            <h2>Log in</h2>
            {
              (this.state.invalidUser) &&
              (<Alert key='error-message' variant='warning'>Login Denied!</Alert>)
            }
            <form onSubmit={this.handleSubmit} noValidate>
              <div className='field'>
                <label htmlFor="field">User Name</label>
                <input type='text' name='username' defaultValue={this.state.username} onChange={this.handleUsername} onChange={this.handleChange} noValidate />
                {errors.username.length > 0 &&
                  <span className='error'>{errors.username}</span>}
              </div>
              <div className='field'>
                <label htmlFor="field">Password</label>
                <input type='password' name='password' defaultValue={this.state.password} onChange={this.handlePassword} onChange={this.handleChange} noValidate />
                {errors.password.length > 0 &&
                  <span className='error'>{errors.password}</span>}
              </div>
              <div className='submit'>
                <button>Log in</button>
              </div>
            </form>
          </div>
        </div>
        <footer>
          <p></p>
        </footer>
      </div>
    );
  }
}

export default Login;

