import React from 'react';
import { NavLink } from 'react-router-dom';
import Table from 'react-bootstrap/Table';
import axios from 'axios';
import { connect } from 'react-redux';
import Header from './Header.jsx';


class View extends React.Component {
    constructor(props) {

        super(props);

        this.state = {

            claims: [],
        }
    };

    componentDidMount() {
        axios.get(`http://localhost:7000/claims`)
            .then(res => {
                const claims = res.data;
                this.props.dispatch(this.viewList(claims))
            })
    }
    viewList(claims) {
        return {
            type: 'LIST',
            claims: claims
        }
    }
    render() {
        console.log('Claims List', this.props.claims);
        return (
            <div>
                <Header />
                <div className='wrap'>
                    <h2>View Claim Summary</h2>
                    <h1>{this.props.username}</h1>
                    <Table striped bordered hover variant="dark">
                        <thead>
                            <tr>
                                <th>Employee ID</th>
                                <th>Employee Name</th>
                                <th>Claim Number</th>
                                <th>Claim Type</th>
                                <th>Claim Programs</th>
                                <th>Claim Start date</th>
                                <th>Claim End date</th>
                                <th>Update Claim Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.props.claims.map((claim,index) => <tr key={index}>
                                <td>{claim.id}</td>
                                <td>{`${claim.first_name} ${claim.last_name}`}</td>
                                <td>{claim.claim_num}</td>
                                <td>{claim.claim_type}</td>
                                <td>{claim.claim_pro}</td>
                                <td>{claim.claim_sd}</td>
                                <td>{claim.claim_ed}</td>
                                <td><NavLink to={`/submit/${claim.id}`} >UPDATE</NavLink></td>
                            </tr>)}
                        </tbody>
                    </Table>
                </div>
                <footer>
                    <p></p>
                </footer>
            </div>
        );
    }
}
const mapStateToProps = state => {

    console.log('App state', state);

    return { claims: state.claims }

}

export default connect(mapStateToProps)(View);