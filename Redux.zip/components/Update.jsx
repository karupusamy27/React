import React from 'react';
import Header from './Header.jsx';


class Update extends React.Component {
    
    render() {
        return (
            <div>
                <Header />
                <div className='wrap'>
                    <h2 className="center">Update Successfully!!!</h2>  
                </div>
                <footer>
                    <p></p>
                </footer>
            </div>
        );
    }
}

export default Update;