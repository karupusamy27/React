import React from 'react';
import { NavLink } from 'react-router-dom';




class Header extends React.Component {
    constructor(props) {

        super(props);

        this.state = {
            curTime: new Date().toLocaleString()
        }
    };

    render() {
        return (
            <div>
                <header>
                    <h1>Claim Management System</h1>
                </header>
                <div className="topnav" >
                    <NavLink to="/login" className="active">Login</NavLink>
                    <NavLink to="/home" >Home</NavLink>
                    <NavLink to="/view" >View Claim Summary</NavLink>
                    <NavLink to="/submit">Update Claim</NavLink>
                    <div className="topnav_right">
                        <p>Welcome</p>
                        <p>{this.state.curTime}</p>
                        <NavLink to="/login">Logout</NavLink>
                    </div>
                </div>
            </div>
        );
    }
}
export default Header;